<?php
session_start();
include "koneksi.php";

if (isset($_GET['fotoID']) && isset($_SESSION['UserID'])) {
    $fotoID = $_GET['fotoID'];
    $userID = $_SESSION['UserID'];

    // Cek apakah sudah like
    $query = "SELECT * FROM likefoto WHERE FotoID = '$fotoID' AND UserID = '$userID'";
    $result = mysqli_query($con, $query);

    if (mysqli_num_rows($result) > 0) {
        // Jika sudah like, hapus like
        $query = "DELETE FROM likefoto WHERE FotoID = '$fotoID' AND UserID = '$userID'";
        $liked = false;
    } else {
        // Jika belum like, tambahkan like
        $query = "INSERT INTO likefoto (FotoID, UserID, TanggalLike) VALUES ('$fotoID', '$userID', CURDATE())";
        $liked = true;
    }

    // Eksekusi query
    mysqli_query($con, $query);

    $queryLikes = "SELECT COUNT(*) AS jumlah_like FROM likefoto WHERE FotoID = '$fotoID'";
    $queryComments = "SELECT COUNT(*) AS jumlah_komentar FROM komentarfoto WHERE FotoID = '$fotoID'";

    $resultLikes = mysqli_query($con, $queryLikes);
    $resultComments = mysqli_query($con, $queryComments);

    $rowLikes = mysqli_fetch_assoc($resultLikes);
    $rowComments = mysqli_fetch_assoc($resultComments);

    echo json_encode([
        'success' => true,
        'liked' => $liked,
        'likes' => $rowLikes['jumlah_like'],
        'comments' => $rowComments['jumlah_komentar'] // Mengembalikan jumlah komentar
    ]);

    

}
?>
