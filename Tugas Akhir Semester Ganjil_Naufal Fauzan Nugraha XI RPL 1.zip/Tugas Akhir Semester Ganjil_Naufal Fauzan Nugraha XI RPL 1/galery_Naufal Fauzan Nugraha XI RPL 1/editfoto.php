<?php
session_start();
include "koneksi.php";

// Periksa login
if (!isset($_SESSION['UserID'])) {
    header("Location: login.php");
    exit();
}

$userID = $_SESSION['UserID'];
$role = $_SESSION['role'];

// Periksa apakah fotoID diberikan
if (!isset($_GET['fotoID'])) {
    die("Foto tidak ditemukan.");
}

$fotoID = $_GET['fotoID'];

// Ambil data foto
$query = "SELECT * FROM foto WHERE FotoID = '$fotoID'";
$result = mysqli_query($con, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    die("Foto tidak ditemukan.");
}

$foto = mysqli_fetch_assoc($result);

// Periksa akses
if (!($role == 'Admin' || $foto['UserID'] == $userID)) {
    die("Akses ditolak. Anda tidak memiliki izin untuk mengedit foto ini.");
}

// Jika form dikirim
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $judulFoto = mysqli_real_escape_string($con, $_POST['judulFoto']);
    $deskripsiFoto = mysqli_real_escape_string($con, $_POST['deskripsiFoto']);
    $albumID = mysqli_real_escape_string($con, $_POST['albumID']);
    $tanggalUnggah = mysqli_real_escape_string($con, $_POST['tanggalUnggah']);

    // Proses upload file (jika ada file baru)
    if (!empty($_FILES['lokasiFoto']['name'])) {
        $lokasiFoto = $_FILES['lokasiFoto']['name'];
        $targetDir = "uploads/";
        $targetFile = $targetDir . basename($lokasiFoto);

        if (move_uploaded_file($_FILES['lokasiFoto']['tmp_name'], $targetFile)) {
            $updateQuery = "UPDATE foto 
                            SET JudulFoto = '$judulFoto', DeskripsiFoto = '$deskripsiFoto', AlbumID = '$albumID', LokasiFoto = '$lokasiFoto', TanggalUnggah = '$tanggalUnggah' 
                            WHERE FotoID = '$fotoID'";
        } else {
            die("Gagal mengupload file.");
        }
    } else {
        $updateQuery = "UPDATE foto 
                        SET JudulFoto = '$judulFoto', DeskripsiFoto = '$deskripsiFoto', AlbumID = '$albumID', TanggalUnggah = '$tanggalUnggah' 
                        WHERE FotoID = '$fotoID'";
    }

    if (mysqli_query($con, $updateQuery)) {
        header("Location: dashboard.php");
        exit();
    } else {
        die("Gagal memperbarui foto: " . mysqli_error($con));
    }
}

// Ambil data album untuk dropdown
$albumQuery = "SELECT * FROM album";
$albumResult = mysqli_query($con, $albumQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Foto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1>Edit Foto</h1>
    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="lokasiFoto" class="form-label">Foto Saat Ini</label><br>
            <img src="uploads/<?php echo htmlspecialchars($foto['LokasiFoto']); ?>" alt="Foto" class="img-thumbnail mb-3" style="max-width: 300px;">
        </div>
        <div class="mb-3">
            <label for="judulFoto" class="form-label">Judul Foto</label>
            <input type="text" name="judulFoto" class="form-control" id="judulFoto" value="<?php echo htmlspecialchars($foto['JudulFoto']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="deskripsiFoto" class="form-label">Deskripsi Foto</label>
            <textarea name="deskripsiFoto" class="form-control" id="deskripsiFoto" rows="3" required><?php echo htmlspecialchars($foto['DeskripsiFoto']); ?></textarea>
        </div>
        <div class="mb-3">
            <label for="albumID" class="form-label">Album</label>
            <select name="albumID" class="form-control" id="albumID" required>
                <?php while ($album = mysqli_fetch_assoc($albumResult)): ?>
                    <option value="<?php echo $album['AlbumID']; ?>" <?php if ($foto['AlbumID'] == $album['AlbumID']) echo 'selected'; ?>>
                        <?php echo $album['NamaAlbum']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="tanggalUnggah" class="form-label">Tanggal Unggah</label>
            <input type="date" name="tanggalUnggah" class="form-control" id="tanggalUnggah" value="<?php echo htmlspecialchars($foto['TanggalUnggah']); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        <a href="dashboard.php" class="btn btn-secondary">Batal</a>
    </form>
</div>
</body>
</html>