<?php
session_start();
include "koneksi.php";

// Periksa apakah pengguna sudah login
$isLoggedIn = isset($_SESSION['UserID']) && !empty($_SESSION['UserID']);
$userID = $isLoggedIn ? $_SESSION['UserID'] : null;

// Ambil Role dan Username
$role = null;
$username = null;

if ($userID) {
    $query = "SELECT user.Username, role.RoleName 
              FROM user 
              INNER JOIN role ON user.RoleID = role.RoleID 
              WHERE user.UserID = '$userID'";
    $result = mysqli_query($con, $query);

    if ($result) {
        $userData = mysqli_fetch_assoc($result);

        if ($userData) {
            $_SESSION['role'] = $userData['RoleName'];
            $_SESSION['Username'] = $userData['Username'];

            $role = $userData['RoleName'];
            $username = $userData['Username'];
        } else {
            $_SESSION['role'] = null;
            $_SESSION['Username'] = null;
        }
    } else {
        die("Query error: " . mysqli_error($con));
    }
} else {
    $_SESSION['role'] = null;
    $_SESSION['Username'] = null;
}

// Ambil input pencarian
$search = isset($_GET['search']) ? mysqli_real_escape_string($con, $_GET['search']) : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/nav.css">  
    <style>
        /* Reset dan dasar */
body {
    margin: 0;
    padding: 0;
    font-family: 'Poppins', sans-serif;
    color: #f5f5f5;
    background-color: #000000;
    padding-top: 80px;
    display: flex;
    flex-direction: column;
    min-height: 100vh; 
}

.main-content {
    flex: 1; 
}


/* Hero Section */
.hero-header {
    position: relative;
    background: url('image/bg.png') no-repeat center center/cover;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    color: #f5f5f5;
    margin-top: -80px;
}

.hero-content {
    z-index: 1;
}

/* Animasi Mengetik dan Berkedip */
.hero-content h2 {
    font-size: 3.5em;
    margin-bottom: 20px;
    text-transform: uppercase;
    font-weight: 700;
    letter-spacing: 3px;
    text-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
    overflow: hidden; 
    white-space: nowrap; 
    border-right: 4px solid #16a085; 
    animation: typing 5s steps(40, end), blink-caret 0.75s step-end infinite;
}

/* Animasi Mengetik */
@keyframes typing {
    from {
        width: 0;
    }
    to {
        width: 100%;
    }
}

/* Animasi Kursor Berkedip */
@keyframes blink-caret {
    0%, 100% {
        border-color: transparent;
    }
    50% {
        border-color: #16a085;
    }
}

/* Greeting Text */
.hero-content .greeting {
    font-size: 1.5em;
    color: #ffffff;
    font-weight: 600;
    margin-bottom: 10px;
    animation: fadeIn 1.5s ease-in-out;
}

.hero-content .greeting span {
    font-style: italic;
    color: #1abc9c;
}

/* Tagline Animation */
.hero-content .tagline {
    font-size: 1.2em;
    color: #dcdcdc;
    font-weight: 400;
    margin-top: 10px;
    margin-bottom: 15px;
    animation: slideIn 2s ease-in-out;
}

/* Subtext */
.hero-content .subtext {
    font-size: 1.1em;
    color: #b3b3b3;
    font-weight: 300;
    margin-top: 20px;
    animation: fadeIn 2.5s ease-in-out;
}

/* Animasi Fade-In */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Animasi Slide-In */
@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateX(-30px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

/* Responsive Design */
@media (max-width: 768px) {
    .hero-content {
        padding: 30px 15px;
    }

    .hero-content h2 {
        font-size: 2.5em;
    }

    .hero-content .tagline, 
    .hero-content .subtext {
        font-size: 1em;
    }

    .hero-content .greeting {
        font-size: 1.2em;
    }
}

/* Kontainer Utama */
.container {
    padding: 30px;
}

/* Tombol */
.btn {
    transition: all 0.3s ease;
}

.btn-primary {
    background-color: #16a085;
    border: none;
}

.btn-primary1 {
    background-color: #16a085;
    border: none;
    
}

.btn-primary:hover {
    background-color: #13a57c;
}

.btn-outline-primary {
    border-color: #16a085;
    color:rgb(0, 69, 55);
}

.btn-outline-primary:hover {
    background-color: #16a085;
    color: white;
}

/* Form Pencarian */
.input-group input {
    background-color: rgb(0, 0, 0);
    color: #f5f5f5;
    border: 1px solid #555555;
    
}

.input-group input:focus {
    outline: none;
    background-color: rgb(0, 0, 0); 
}

/* Pastikan input dan tombol memiliki ukuran sama */
.input-group .form-control, .input-group .btn {
    height: 45px; 
    margin-top: 15px;
}


/* Galeri Foto */
.card {
    background-color: #1a1a1a;
    color: #f5f5f5;
    border: none;
}

.card img {
    transition: transform 0.3s ease, filter 0.3s ease;
    filter: brightness(1.2);
}

.card:hover img {
    transform: scale(1.05);
    filter: brightness(0.8);
}

.card-title {
    color: #ffffff;
}

.card .btn-primary {
    background-color: #16a085;
    border: none;
}

.card .btn-primary:hover {
    background-color: #13a57c;
}

/* Notifikasi */
.dropdown-menu {
    background-color: #1a1a1a;
    color: #f5f5f5;
    border: none;
}

.dropdown-menu p {
    margin: 0;
}

.icon-like {
    color: #555; 
    transition: color 0.3s ease;
}

.bi-heart.liked {
    color: #dc3545; 
    transition: color 0.3s ease;
}

footer {
    text-align: center;
    padding: 20px;
    background-color: #000000;
    color: #f5f5f5;
}
        
    </style>
</head>
<body>
<header class="hero-header">
<nav class="navbar">
        <div class="logo">
            <img src="image/LOGO.png" alt="logo">
        </div>
        <ul class="nav-links">
            <li><a href="dashboard.php" class="nav-item active">Home</a></li>
            <li><a href="about.php" class="nav-item">About</a></li>
            <li><a href="gallery.php" class="nav-item">Gallery</a></li>
            <li><a href="contact.php" class="nav-item ">Contact</a></li>
        </ul>
        <div>
            <?php if ($isLoggedIn): ?>
                <a href="profile.php" class="btn user-icon">
                    <i class="bi bi-person-circle"></i>
                    <?php echo htmlspecialchars($_SESSION['Username'], ENT_QUOTES, 'UTF-8'); ?>
                </a>
            <?php else: ?>
                <a href="login.php" class="btn btn-outline-primary">
                    Sign In/Up
                </a>
            <?php endif; ?>
        </div>
    </nav>
    <div class="hero-content">
        <?php if ($isLoggedIn): ?>
            <p class="greeting">Hai, <span><?php echo $_SESSION['Username']; ?></span> !</p>
        <?php endif; ?>
        <h2>Welcome to Snapict</h2>
        <h4 class="tagline">Ciptakan, Abadikan, dan Rayakan Kehidupan dalam Setiap Jepretan</h4>
        <h3 class="subtext">Platform terpadu Anda untuk koleksi foto yang menakjubkan.</h3>
    </div>
</header>

<div class="container mt-5">
    <h1>Dashboard</h1>
    <div class="d-flex justify-content-start gap-3">
        <?php if ($role == 'Admin'): ?>
            <a href="kelolauser.php" class="btn btn-primary">
                <i class="bi bi-person-lines-fill"></i> Kelola Pengguna
            </a>
            <a href="kelolafoto.php" class="btn btn-secondary">
                <i class="bi bi-image "></i> Kelola Foto
            </a>
        <?php endif; ?>

        <?php if ($isLoggedIn): ?>
            <a href="uploadfoto.php" class="btn btn-success">
                <i class="bi bi-upload"></i> Upload Foto
            </a>
        <?php endif; ?>

        <!--<div class="dropdown">
            <button class="btn btn-outline-secondary position-relative" onclick="showNotifications()">
                <i class="bi bi-bell"></i>
                <span id="notif-count" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="display: none;">0</span>
            </button>
            <div id="notif-dropdown" class="dropdown-menu dropdown-menu-end p-3" style="display: none; max-height: 300px; overflow-y: auto;">
                <p class="text-muted">Tidak ada notifikasi baru.</p>
            </div>
        </div>-->
    </div>
    
    <!-- Form Pencarian -->
    <form method="GET" class="mb-4">
        <div class="input-group d-flex w-100">
            <input type="text" name="search" class="form-control flex-grow-1" placeholder="Cari foto berdasarkan judul atau album" value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit" class="btn btn-primary1 btn-sm">Cari</button>
        </div>
    </form>

    <!-- Notifikasi Hasil Pencarian -->
    <?php if (!empty($search)): ?>
        <div class="alert alert-info">
            Hasil pencarian dari <strong>"<?php echo htmlspecialchars($search); ?>"</strong>:
        </div>
    <?php endif; ?>

    <h2>Galeri Foto</h2>
    <div class="row">
        <?php
        // Query untuk menampilkan foto
        $query = "SELECT foto.FotoID, foto.JudulFoto, foto.DeskripsiFoto, foto.LokasiFoto, foto.TanggalUnggah, 
                 album.NamaAlbum, user.Username, user.UserID AS PengunggahID,
                 (SELECT COUNT(*) FROM komentarfoto WHERE FotoID = foto.FotoID) AS jumlah_komentar,
                 (SELECT COUNT(*) FROM likefoto WHERE FotoID = foto.FotoID) AS jumlah_likes,
                 (SELECT COUNT(*) FROM likefoto WHERE FotoID = foto.FotoID AND UserID = '$userID') AS sudah_like
          FROM foto
          INNER JOIN album ON foto.AlbumID = album.AlbumID
          INNER JOIN user ON foto.UserID = user.UserID";

        if (!empty($search)) {
            $query .= " WHERE foto.JudulFoto LIKE '%$search%' OR album.NamaAlbum LIKE '%$search%'";
        }

        $query .= " ORDER BY foto.TanggalUnggah DESC";

        $result = mysqli_query($con, $query);

        // Tampilkan hasil pencarian
        if (mysqli_num_rows($result) > 0):
            while ($row = mysqli_fetch_assoc($result)):
                // Periksa apakah foto telah di-like oleh pengguna
                $fotoID = $row['FotoID'];
                $queryLiked = "SELECT * FROM likefoto WHERE FotoID = $fotoID AND UserID = $userID";
                if (!empty($userID) && !empty($fotoID)) {
                    $queryLiked = "SELECT * FROM likefoto WHERE FotoID = $fotoID AND UserID = $userID";
                    $isLiked = mysqli_num_rows(mysqli_query($con, $queryLiked)) > 0;
                } else {
                    $isLiked = false; // Default jika tidak ada userID atau fotoID
                }
                
            ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="uploads/<?php echo $row['LokasiFoto']; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($row['JudulFoto']); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($row['JudulFoto']); ?></h5>
                            <p id="likes-count-<?php echo $row['FotoID']; ?>"><?php echo $row['jumlah_likes']; ?> Likes ‎ | ‎ ‎ 
                                <span id="comments-count-<?php echo $row['FotoID']; ?>"><?php echo $row['jumlah_komentar']; ?> Comments</span>
                            </p>

                            <a href="detailfoto.php?fotoID=<?php echo $row['FotoID']; ?>" class="btn btn-primary">Lihat Detail </a>
                            <button class="btn btn-outline-danger" onclick="likeFoto(<?php echo $row['FotoID']; ?>)">
                                <i class="bi <?php echo ($row['sudah_like'] > 0) ? 'bi-heart-fill liked' : 'bi-heart'; ?>" 
                                id="like-icon-<?php echo $row['FotoID']; ?>"></i>
                            </button>

                        </div>
                    </div>
                </div>
            <?php endwhile;
        else: ?>
            <p class="text-muted">Tidak ada foto yang ditemukan.</p>
        <?php endif; ?>
    </div>
</div>

<footer>
    <p>&copy; 2025 Snapict. All Rights Reserved.</p>
</footer>


<script>
function likeFoto(fotoID) {
    const isLoggedIn = <?php echo json_encode($isLoggedIn); ?>;

    if (!isLoggedIn) {
        if (confirm("Anda harus login untuk memberikan Like. Apakah Anda ingin login sekarang?")) {
            window.location.href = 'login.php';
        }
        return;
    }

    fetch(`like.php?fotoID=${fotoID}`)
        .then(response => response.json())
        .then(data => {
            // Update jumlah likes jika berhasil
            if (data.success) {
                const likeIcon = document.getElementById(`like-icon-${fotoID}`);
                const likesCountElement = document.getElementById(`likes-count-${fotoID}`);
                const commentsCountElement = document.getElementById(`comments-count-${fotoID}`); 

                // Toggle the like icon
                if (data.liked) {
                    likeIcon.classList.remove('bi-heart'); 
                    likeIcon.classList.add('bi-heart-fill');
                } else {
                    likeIcon.classList.remove('bi-heart-fill'); 
                    likeIcon.classList.add('bi-heart');
                }

                // Update jumlah like di halaman
                if (likesCountElement) {
                    likesCountElement.textContent = `${data.likes} Likes ‎ |‎ ‎ ‎ ${data.comments} Comments`; // Jangan hapus bagian komentar
                }
            }
        })
        .catch(error => console.error("Error liking photo:", error));
}


function showNotifications() {
    fetch('notifikasi.php')
        .then(response => response.json())
        .then(data => {
            const dropdown = document.getElementById('notif-dropdown');
            dropdown.style.display = 'block';

            if (data.length > 0) {
                dropdown.innerHTML = data.map(notif => `
                    <div class="dropdown-item">
                        <p>${notif.IsiNotifikasi}</p>
                        <small class="text-muted">${new Date(notif.TanggalDibuat).toLocaleString()}</small>
                    </div>
                    <hr>
                `).join('');
            } else {
                dropdown.innerHTML = '<p class="text-muted">Tidak ada notifikasi baru.</p>';
            }
            updateNotifCount();
        })
        .catch(error => console.error("Error fetching notifications:", error));
}

function updateNotifCount() {
    fetch('notifikasi.php')
        .then(response => response.json())
        .then(data => {
            const notifCount = data.filter(notif => notif.SudahDilihat == 0).length;
            const badge = document.getElementById('notif-count');
            if (notifCount > 0) {
                badge.textContent = notifCount;
                badge.style.display = 'inline';
            } else {
                badge.style.display = 'none';
            }
        });
}

setInterval(updateNotifCount, 30000); 
updateNotifCount();
</script>


</body>
</html>
