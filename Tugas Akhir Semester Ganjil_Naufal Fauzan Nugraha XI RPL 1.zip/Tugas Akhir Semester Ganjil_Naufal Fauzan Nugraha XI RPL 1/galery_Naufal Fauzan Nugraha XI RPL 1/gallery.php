<?php
session_start();
include "koneksi.php"; // Pastikan $con didefinisikan di sini

// Periksa apakah pengguna sudah login
$isLoggedIn = isset($_SESSION['UserID']);

// Pastikan UserID ada sebelum melakukan query
$userID = $isLoggedIn ? $_SESSION['UserID'] : null;

// Default role pengguna
$isAdmin = false;
$role = '';

// Jika UserID ada, ambil role dari database
if ($userID) {
    // Gunakan prepared statements untuk keamanan tambahan
    $stmt = $con->prepare("SELECT role.RoleName FROM user 
                           INNER JOIN role ON user.RoleID = role.RoleID
                           WHERE user.UserID = ?");
    $stmt->bind_param("i", $userID); // Asumsi UserID adalah integer
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $row = $result->fetch_assoc()) {
        $role = $row['RoleName'];
        $_SESSION['role'] = $role; // Simpan role di session
        $isAdmin = (strtolower($role) === 'admin'); // Set isAdmin jika RoleName adalah admin (case-insensitive)
    } else {
        // Jika tidak ada hasil, logout pengguna atau atur sesi sesuai kebutuhan
        // session_destroy();
        // header("Location: login.php");
        // exit();
    }
    $stmt->close();
}

// Proses tambah album
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_album'])) {
    if ($isAdmin) { // Tambah album hanya jika admin
        // Validasi input tambahan dapat dilakukan di sini
        $namaAlbum = $con->real_escape_string(trim($_POST['nama_album']));
        $deskripsi = $con->real_escape_string(trim($_POST['deskripsi_album']));
        $tanggalDibuat = date('Y-m-d');

        $stmt = $con->prepare("INSERT INTO album (NamaAlbum, Deskripsi, TanggalDibuat, UserID) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $namaAlbum, $deskripsi, $tanggalDibuat, $userID);

        if ($stmt->execute()) {
            $success = true; // Tandai bahwa proses berhasil
        } else {
            echo "<p>Error: " . htmlspecialchars($stmt->error) . "</p>";
        }
        $stmt->close();
    } else {
        echo "<p style='color:red;'>Akses ditolak. Hanya admin yang dapat menambahkan album.</p>";
    }
}

// Ambil semua album dari database
$albums = $con->query("SELECT * FROM album");

// Periksa apakah ada parameter album_id
$albumSelected = isset($_GET['album_id']) ? intval($_GET['album_id']) : null;

// Ambil foto berdasarkan album yang dipilih, atau semua jika tidak ada yang dipilih
if ($albumSelected !== null && $albumSelected > 0) {
    $photos = $con->query("SELECT * FROM foto WHERE AlbumID = $albumSelected");
    $selectedAlbum = $con->query("SELECT * FROM album WHERE AlbumID = $albumSelected")->fetch_assoc();
} else {
    $photos = $con->query("SELECT * FROM foto");
}

// Debugging Sementara (Hapus setelah selesai)
// echo "Role: " . htmlspecialchars($role) . "<br>";
// echo "Is Admin: " . ($isAdmin ? 'Yes' : 'No') . "<br>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/nav.css">
    <style>

/* Mengatur body agar mengisi seluruh layar */
body {
    font-family: 'Poppins', sans-serif;
    background-color: #000; /* Latar belakang hitam */
    color: #f5f5f5; /* Teks putih */
    margin-top: 100px;
    position: relative;
    min-height: 100vh; /* Mengisi seluruh tinggi layar */
}

/* Menjaga footer tetap di bawah */
footer {
    position: absolute;
    bottom: 0;
    width: 100%;
    text-align: center;
    padding: 20px;
    background-color: #000;
    color: #f5f5f5;
    margin-top: 50px;
}


.album-input-container {
    margin: 50px auto;
    padding: 20px;
    max-width: 400px;
    background: rgba(0, 0, 0, 0.8);
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
    text-align: center;
}

.album-input-container h2 {
    font-size: 28px;
    color: #16a085;
    margin-bottom: 20px;
}

.album-input-container label {
    font-size: 16px;
    color: #f5f5f5;
    text-align: left;
    display: block;
    margin-bottom: 5px;
}

.album-input-container input,
.album-input-container textarea {
    width: 100%;
    padding: 10px;
    border-radius: 5px;
    background: rgba(255, 255, 255, 0.1);
    border: none;
    color: #f5f5f5;
    margin-bottom: 15px;
    font-size: 14px;
}

.album-input-container button {
    width: 50%;
    padding: 10px;
    border-radius: 30px;
    background: #16a085;
    border: none;
    color: #fff;
    font-weight: bold;
    font-size: 16px;
    cursor: pointer;
    transition: background 0.3s ease;
}

.album-input-container button:hover {
    background: #13a077;
}

/* Gallery album list */
.gallery-album-list {
    display: flex;
    gap: 20px;
    justify-content: center;
    margin: 30px 0;
}

.gallery-album-list a {
    padding: 12px 18px;
    color: #f5f5f5;
    border: 2px solid #fff;
    border-radius: 50px;
    text-decoration: none;
    text-transform: uppercase;
    font-size: 13px;
    font-weight: bold;
}

.gallery-album-list a:hover {
    background-color: #16a085;
    color: #fff;
}

/* Galeri Foto */
.gallery-photos {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

.gallery-photos h3 {
    text-align: center;
    color: #ffffff;
    margin-bottom: 30px;
    font-size: 2em;
}

.gallery-photos .row {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: center;
    margin-bottom: 100px;
}

.gallery-photos .card {
    background-color: #1a1a1a;
    color: #f5f5f5;
    border: none;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
}

.gallery-photos .card:hover {
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.6);
}

.gallery-photos .card img {
    transition: transform 0.3s ease, filter 0.3s ease;
    filter: brightness(1.2);
    width: 100%;
    height: auto;
}

.gallery-photos .card:hover img {
    transform: scale(1.05);
    filter: brightness(0.8);
}

.gallery-photos .card-body {
    padding: 15px;
    text-align: center;
}

.gallery-photos .card-title {
    color: #ffffff;
    font-size: 1.2em;
    margin-bottom: 10px;
}

.gallery-photos .card-text {
    font-size: 0.9em;
    color: #aaa;
    margin-bottom: 15px;
}

.gallery-photos .btn-primary {
    background-color: #16a085;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    font-size: 0.9em;
    text-transform: uppercase;
    transition: background-color 0.3s ease;
}

.gallery-photos .btn-primary:hover {
    background-color: #13a57c;
    color: #fff;
}

</style>

        
    <script>
        // Jika berhasil, tampilkan notifikasi dan redirect
        <?php if (isset($success) && $success): ?>
            window.onload = function() {
                alert('Album berhasil ditambahkan!');
                window.location.href = "gallery.php";
            };
        <?php endif; ?>
    </script>
</head>
<body>
<header class="hero-header">
    <nav class="navbar">
        <div class="logo">
            <img src="image/LOGO.png" alt="logo">
        </div>
        <ul class="nav-links">
            <li><a href="dashboard.php" class="nav-item">Home</a></li>
            <li><a href="about.php" class="nav-item">About</a></li>
            <li><a href="gallery.php" class="nav-item active">Gallery</a></li>
            <li><a href="contact.php" class="nav-item">Contact</a></li>
        </ul>
        <div>
            <?php if ($isLoggedIn): ?>
                <a href="profile.php" class="btn user-icon">
                    <i class="bi bi-person-circle"></i>
                    <?php echo htmlspecialchars($_SESSION['Username'], ENT_QUOTES, 'UTF-8'); ?>
                </a>
            <?php else: ?>
                <a href="login.php" class="btn btn-outline-primary">
                    Sign In/Up
                </a>
            <?php endif; ?>
        </div>
    </nav>
</header>
<main class="gallery-container">

    <?php if ($isLoggedIn && $isAdmin): ?>
        <div class="album-input-container">
            <h2>Tambah Album Baru</h2>
            <form method="POST">
                <div class="mb-3">
                    <label for="nama_album" class="form-label">Nama Album :</label>
                    <input type="text" name="nama_album" id="nama_album" class="form-control" placeholder="Masukkan nama album" required>
                </div>
                
                <div class="mb-3">
                    <label for="deskripsi_album" class="form-label">Deskripsi Album :</label>
                    <textarea name="deskripsi_album" id="deskripsi_album" class="form-control" placeholder="Masukkan deskripsi album" required></textarea>
                </div>
                
                <button type="submit" name="tambah_album" class="btn btn-primary">Simpan Album</button>
            </form>
        </div>
        <hr>
    <?php endif; ?>

    <section class="gallery-album-list">
        <a href="gallery.php">Semua Foto</a>
        <?php while ($album = $albums->fetch_assoc()): ?>
            <a href="gallery.php?album_id=<?php echo $album['AlbumID']; ?>">
                <?php echo htmlspecialchars($album['NamaAlbum']); ?>
            </a>
        <?php endwhile; ?>
    </section>

</section>

<section class="gallery-photos">
    <h3 class="text-center mb-5">
        Foto <?php echo isset($selectedAlbum) ? 'Album : ' . htmlspecialchars($selectedAlbum['NamaAlbum']) : 'Semua Album'; ?>
    </h3>
    <div class="row">
        <?php if ($photos && $photos->num_rows > 0): ?>
            <?php while ($photo = $photos->fetch_assoc()): ?>
                <div class="col-lg-3 col-md-4 col-sm-6 d-flex align-items-stretch">
                    <div class="card">
                        <img src="uploads/<?php echo htmlspecialchars($photo['LokasiFoto']); ?>" 
                             class="card-img-top" 
                             alt="<?php echo htmlspecialchars($photo['JudulFoto']); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($photo['JudulFoto']); ?></h5>
                            <p class="card-text"><?php echo htmlspecialchars($photo['DeskripsiFoto']); ?></p>
                            <a href="detailfoto.php?fotoID=<?php echo $photo['FotoID']; ?>" 
                               class="btn btn-primary">Detail Foto</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p class="text-muted text-center">Tidak ada foto untuk kategori ini.</p>
        <?php endif; ?>
    </div>
</section>

<footer>
    <p>&copy; 2025 Snapict. All Rights Reserved.</p>
</footer>

</main>
</body>
</html>
