<?php
session_start();
include "koneksi.php";

// Pastikan session key "UserID" aman diakses
$isLoggedIn = isset($_SESSION['UserID']) && !empty($_SESSION['UserID']);
$userID = $_SESSION['UserID'] ?? null;

// Ambil FotoID dari URL
$fotoID = $_GET['fotoID'] ?? null;

if (!$fotoID) {
    die("Foto tidak ditemukan.");
}

// Query untuk mengambil detail foto
$query = "SELECT foto.FotoID, foto.JudulFoto, foto.DeskripsiFoto, foto.LokasiFoto, foto.TanggalUnggah, 
                 album.NamaAlbum, user.Username, user.UserID AS PengunggahID,
                 (SELECT COUNT(*) FROM komentarfoto WHERE FotoID = foto.FotoID) AS jumlah_komentar,
                 (SELECT COUNT(*) FROM likefoto WHERE FotoID = foto.FotoID) AS jumlah_likes,
                 (SELECT COUNT(*) FROM likefoto WHERE FotoID = foto.FotoID AND UserID = '$userID') AS is_liked
          FROM foto
          INNER JOIN album ON foto.AlbumID = album.AlbumID
          INNER JOIN user ON foto.UserID = user.UserID
          WHERE foto.FotoID = '$fotoID'";
$result = mysqli_query($con, $query);

// Check jika query berhasil
if ($result && mysqli_num_rows($result) > 0) {
    $foto = mysqli_fetch_assoc($result);
    $isLiked = ($foto['is_liked'] > 0); 
} else {
    die("Foto tidak ditemukan.");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Foto</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/nav.css">
    <style>
/* Body */
body {
    font-family: 'Poppins', sans-serif;
    background-color: #000000; /* Hitam penuh */
    color:rgb(255, 255, 255); /* Abu-abu terang untuk teks */
    margin-top: 140px;
    padding: 0;
    line-height: 1.6;
    display: flex;
    flex-direction: column;
    min-height: 100vh; /* Pastikan body mengisi seluruh tinggi layar */
}


/* Footer */
footer {
    text-align: center;
    background-color:rgb(0, 0, 0);
    color:rgb(255, 255, 255);
    padding: 10px 0;
    box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.2); /* Bayangan untuk footer */
    font-family: 'Poppins';
}




/* Container */
.container {
    margin: 40px auto; 
    max-width: 700px;
    background-color: #121212; /* Hitam lembut */
    padding: 20px 30px;
    border-radius: 12px; /* Sudut lebih bulat */
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.6); /* Efek elegan */
    flex: 1;
}

/* Title */
h1 {
    font-size: 1.8rem; /* Ramping */
    color: #1abc9c; /* Hijau elegan */
    margin-bottom: 15px;
    text-align: center;
    font-weight: 500; /* Ramping tapi tetap tegas */
}

/* Image */
img.img-fluid {
    width: 100%;
    border-radius: 10px;
    margin-bottom: 20px;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.5); /* Bayangan ringan */
}

/* Text Styling */
p {
    font-size: 0.9rem; /* Lebih kecil */
    color: #b3b3b3; /* Abu-abu netral */
    margin-bottom: 12px;
}

strong {
    color: #1abc9c;
}

/* Comments Section */
.comment {
    background-color: #1b1b1b;
    padding: 15px;
    border-radius: 10px;
    margin-bottom: 12px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
}

.comment p {
    margin: 0;
    font-size: 0.85rem; /* Lebih kecil dan minimalis */
    color: #e0e0e0;
}

.comment strong {
    color: #1abc9c;
    font-weight: 500;
}

.comment button {
    background-color: transparent;
    color: #e74c3c; /* Warna merah untuk tombol hapus */
    font-size: 0.8rem;
    border: none;
    cursor: pointer;
    text-decoration: underline;
    padding: 0;
    transition: all 0.2s ease;
}

.comment button:hover {
    color: #c0392b;
}

/* Form Styling */
form {
    background-color: #1b1b1b;
    padding: 20px;
    border-radius: 10px;
    margin-top: 20px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
}

textarea.form-control {
    background-color: #121212;
    border: none;
    border-radius: 8px;
    padding: 12px;
    font-size: 0.9rem;
    color: #e0e0e0;
    resize: vertical;
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.2);
}

textarea.form-control:focus {
    border: 1px solid #1abc9c;
    outline: none;
    box-shadow: 0 0 8px rgba(26, 188, 156, 0.6);
}

/* Responsive Design */
@media (max-width: 768px) {
    .container {
        padding: 20px;
    }

    h1 {
        font-size: 1.5rem;
    }

    button,
    a.btn {
        width: 100%;
        padding: 12px;
        margin: 5px 0;
    }
}

.bi-arrow-left .btn-secondary{
    background: #1abc9c ;
    color: #fff;
}
.icon-like {
    color: #555; /* Warna default abu-abu */
    transition: color 0.3s ease;
}

.bi-heart.liked {
    color: #dc3545; /* Warna merah ketika di-like */
    transition: color 0.3s ease;
}

button.btn i.bi-heart,
button.btn i.bi-heart-fill {
    color: #dc3545; /* Warna merah default */
}


    </style>
</head>
<body>

<header class="hero-header">
    <nav class="navbar">
        <div class="logo">
            <img src="image/LOGO.png" alt="logo">
        </div>
        <ul class="nav-links">
            <li><a href="dashboard.php" class="nav-item">Home</a></li>
            <li><a href="about.php" class="nav-item">About</a></li>
            <li><a href="gallery.php" class="nav-item">Gallery</a></li>
            <li><a href="contact.php" class="nav-item">Contact</a></li>
        </ul>
        <div>
            <?php if ($isLoggedIn): ?>
                <a href="profile.php" class="btn user-icon">
                    <i class="bi bi-person-circle"></i>
                    <?php echo htmlspecialchars($_SESSION['Username'], ENT_QUOTES, 'UTF-8'); ?>
                </a>
            <?php else: ?>
                <a href="login.php" class="btn btn-signin">
                    Sign In/Up
                </a>

            <?php endif; ?>
        </div>
    </nav>
</header>

<div class="container mt-5">
    <a href="dashboard.php" class="btn btn-secondary mb-3">
        <i class="bi bi-arrow-left"></i> Kembali
    </a>
    <h1><?php echo $foto['JudulFoto']; ?></h1>
    <img src="uploads/<?php echo $foto['LokasiFoto']; ?>" class="img-fluid" alt="<?php echo $foto['JudulFoto']; ?>">
    <p><strong>Deskripsi:</strong> <?php echo $foto['DeskripsiFoto']; ?></p>
    <p><strong>Album:</strong> <?php echo $foto['NamaAlbum']; ?></p>
    <p><strong>Diunggah oleh:</strong> <?php echo $foto['Username']; ?> pada <?php echo $foto['TanggalUnggah']; ?></p>
    <p><strong id="likes-count-<?php echo $foto['FotoID']; ?>"><?php echo $foto['jumlah_likes']; ?> Likes &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; <?php echo $foto['jumlah_komentar']; ?> Comments</strong></p>

    

    <button class="btn" onclick="likeFoto(<?php echo $foto['FotoID']; ?>)">
        <i class="bi <?php echo ($isLiked) ? 'bi-heart-fill' : 'bi-heart'; ?>" 
        id="like-icon-<?php echo $foto['FotoID']; ?>"></i>
    </button>



    <?php if (isset($_SESSION['UserID']) && $foto['PengunggahID'] == $_SESSION['UserID']): ?>
        <a href="editfoto.php?fotoID=<?php echo $foto['FotoID']; ?>" class="btn btn-warning">Edit Foto</a>
    <?php endif; ?>

    <hr>

    <h2>Komentar</h2>
    <div id="comments-section">
        <?php
        // Ambil komentar foto ini 
        $commentQuery = "SELECT komentarfoto.KomentarID, komentarfoto.IsiKomentar, komentarfoto.UserID AS KomentatorID, 
                                user.Username 
                         FROM komentarfoto 
                         INNER JOIN user ON komentarfoto.UserID = user.UserID 
                         WHERE FotoID = '$fotoID' 
                         ORDER BY TanggalKomentar DESC";

        $commentsResult = mysqli_query($con, $commentQuery);

        while ($comment = mysqli_fetch_assoc($commentsResult)): ?>
            <div class="comment mb-3">
                <p><strong><?php echo $comment['Username']; ?>:</strong> <?php echo $comment['IsiKomentar']; ?></p>
                <?php if (isset($_SESSION['UserID']) && $comment['KomentatorID'] == $_SESSION['UserID']): ?>
                    <button class="btn btn-danger btn-sm" onclick="deleteComment(<?php echo $comment['KomentarID']; ?>)">Hapus</button>
                <?php endif; ?>
            </div>
        <?php endwhile; ?>
    </div>

    <hr>

    <?php if (!isset($_SESSION['UserID'])): ?>
        <h3>Tambah Komentar</h3>
        <p>Anda harus <a href="login.php">login</a> untuk memberikan komentar.</p>
    <?php else: ?>
        <h3>Tambah Komentar</h3>
        <form action="addkomen.php" method="POST">
            <textarea name="komentar" rows="3" class="form-control" placeholder="Tulis komentar..." required></textarea>
            <input type="hidden" name="fotoID" value="<?php echo $foto['FotoID']; ?>">
            <button type="submit" class="btn btn-primary mt-2">Kirim Komentar</button>
        </form>
    <?php endif; ?>


</div>
<footer>
    <p>&copy; 2025 Snapict. All Rights Reserved.</p>
</footer>
<script>
function likeFoto(fotoID) {
    const isLoggedIn = <?php echo json_encode($isLoggedIn); ?>;

    if (!isLoggedIn) {
        if (confirm("Anda harus login untuk memberikan Like. Apakah Anda ingin login sekarang?")) {
            window.location.href = 'login.php';
        }
        return;
    }

    fetch(`like.php?fotoID=${fotoID}`)
        .then(response => response.json())
        .then(data => {
            // Update jumlah likes jika berhasil
            if (data.success) {
                const likeIcon = document.getElementById(`like-icon-${fotoID}`);
                const likesCountElement = document.getElementById(`likes-count-${fotoID}`);

                // Toggle the like icon
                if (data.liked) {
                    likeIcon.classList.remove('bi-heart'); // Ganti dengan ikon penuh
                    likeIcon.classList.add('bi-heart-fill');
                } else {
                    likeIcon.classList.remove('bi-heart-fill'); // Ganti dengan ikon kosong
                    likeIcon.classList.add('bi-heart');
                }

                // Update jumlah like di halaman
                if (likesCountElement) {
                    likesCountElement.textContent = `${data.likes} Likes‎ ‎ ‎ ‎ |‎ ‎ ‎ ‎ ${data.comments} Comments`; // Update jumlah likes dan comments
                }
            }
        })
        .catch(error => console.error("Error liking photo:", error));

}

function deleteComment(komentarID) {
    if (confirm("Apakah Anda yakin ingin menghapus komentar ini?")) {
        fetch(`hapuskomen.php?komentarID=${komentarID}`)
            .then(response => response.text())
            .then(data => {
                if (data === "success") {
                    alert("Komentar berhasil dihapus.");
                    location.reload();
                } else {
                    alert("Gagal menghapus komentar. Silakan coba lagi.");
                }
            })
            .catch(error => console.error("Error:", error));
    }
}

document.querySelector('form').addEventListener('submit', function(event) {
    const isLoggedIn = <?php echo json_encode($isLoggedIn); ?>;

    if (!isLoggedIn) {
        event.preventDefault();  

        if (confirm("Anda harus login untuk memberikan komentar. Apakah Anda ingin login sekarang?")) {
            window.location.href = 'login.php';  
        }
    }
});

</script>
</body>
</html>
