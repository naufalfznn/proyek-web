<?php
session_start();

// Pastikan session sudah dimulai dan pengguna sudah login
if (!isset($_SESSION['Username'])) {
    header("Location: index.php");
    exit();
}

include "koneksi.php";

// Pastikan ada parameter 'id' di URL
if (isset($_GET['id'])) {
    $foto_id = $_GET['id'];
    
    // Ambil lokasi foto dari database
    $query = "SELECT LokasiFoto FROM foto WHERE FotoID = '$foto_id'";
    $result = mysqli_query($con, $query);
    
    // Periksa apakah foto dengan ID tersebut ada
    if ($result && mysqli_num_rows($result) > 0) {
        $foto = mysqli_fetch_assoc($result);

        // Hapus like yang terkait dengan foto dari tabel likefoto
        $delete_likes_query = "DELETE FROM likefoto WHERE FotoID = '$foto_id'";
        mysqli_query($con, $delete_likes_query);

        if (file_exists($foto['LokasiFoto'])) {
            unlink($foto['LokasiFoto']); 
        }

        $delete_photo_query = "DELETE FROM foto WHERE FotoID = '$foto_id'";
        if (mysqli_query($con, $delete_photo_query)) {
            // Berhasil menghapus foto
            $_SESSION['message'] = "Foto berhasil dihapus!";
        } else {

            $_SESSION['message'] = "Error: " . mysqli_error($con);
        }
    } else {        $_SESSION['message'] = "Foto tidak ditemukan!";
    }

    header("Location: dashboard.php");
    exit();
} else {

    $_SESSION['message'] = "ID foto tidak ditemukan!";
    header("Location: dashboard.php");
    exit();
}
?>
