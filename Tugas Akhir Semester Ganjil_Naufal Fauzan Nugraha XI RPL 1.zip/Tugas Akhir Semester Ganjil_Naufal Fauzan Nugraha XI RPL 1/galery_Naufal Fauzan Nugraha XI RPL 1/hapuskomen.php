<?php
session_start();
include "koneksi.php";

// Pastikan pengguna login
if (!isset($_SESSION['UserID']) || empty($_SESSION['UserID'])) {
    die("Unauthorized");
}

$komentarID = isset($_GET['komentarID']) ? $_GET['komentarID'] : null;

if (!$komentarID) {
    die("Komentar tidak ditemukan.");
}

// Validasi kepemilikan komentar
$userID = $_SESSION['UserID'];
$query = "SELECT * FROM komentarfoto WHERE KomentarID = '$komentarID' AND UserID = '$userID'";
$result = mysqli_query($con, $query);

if ($result && mysqli_num_rows($result) > 0) {
    // Hapus komentar
    $deleteQuery = "DELETE FROM komentarfoto WHERE KomentarID = '$komentarID'";
    if (mysqli_query($con, $deleteQuery)) {
        echo "success";
    } else {
        echo "error";
    }
} else {
    echo "error";
}
?>
