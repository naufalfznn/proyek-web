<?php
session_start();
include "koneksi.php";

// Cek apakah data form dikirimkan
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fotoID = $_POST['fotoID'];
    $judul = $_POST['judul'];
    $deskripsi = $_POST['deskripsi'];
    $tanggal = $_POST['tanggal'];
    $album = $_POST['album'];

    // Cek apakah ada foto baru yang diupload
    if ($_FILES['foto']['error'] == 0) {
        $lokasiFoto = $_FILES['foto']['name'];
        move_uploaded_file($_FILES['foto']['tmp_name'], "uploads/" . $lokasiFoto);

        // Update foto beserta informasi lainnya
        $query = "UPDATE foto 
                  SET JudulFoto = '$judul', DeskripsiFoto = '$deskripsi', TanggalUnggah = '$tanggal', LokasiFoto = '$lokasiFoto', AlbumID = '$album' 
                  WHERE FotoID = '$fotoID'";
    } else {
        // Update tanpa mengganti foto
        $query = "UPDATE foto 
                  SET JudulFoto = '$judul', DeskripsiFoto = '$deskripsi', TanggalUnggah = '$tanggal', AlbumID = '$album' 
                  WHERE FotoID = '$fotoID'";
    }

    if (mysqli_query($con, $query)) {
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($con);
    }
}
?>
