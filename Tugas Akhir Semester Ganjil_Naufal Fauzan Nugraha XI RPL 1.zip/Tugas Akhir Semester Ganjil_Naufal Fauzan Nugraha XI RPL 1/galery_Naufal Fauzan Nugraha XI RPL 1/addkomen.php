<?php
session_start();
include "koneksi.php";

// Pastikan pengguna login
if (!isset($_SESSION['UserID']) || empty($_SESSION['UserID'])) {
    die("Anda harus login untuk menambahkan komentar.");
}

$fotoID = isset($_POST['fotoID']) ? $_POST['fotoID'] : null;
$komentar = isset($_POST['komentar']) ? $_POST['komentar'] : null;

if (!$fotoID || !$komentar) {
    die("Data tidak valid.");
}

// Mendapatkan UserID dan Username dari session
$userID = $_SESSION['UserID'];
$username = $_SESSION['Username'];

// Insert komentar ke database
$query = "INSERT INTO komentarfoto (FotoID, UserID, IsiKomentar, TanggalKomentar) 
          VALUES ('$fotoID', '$userID', '$komentar', NOW())";

if (mysqli_query($con, $query)) {
    // Tambahkan notifikasi ke database
    $notifQuery = "INSERT INTO notifikasi (UserID, IsiNotifikasi, TanggalDibuat, SudahDilihat) 
                   VALUES (
                       (SELECT UserID FROM foto WHERE FotoID = '$fotoID'), 
                       '$username telah mengomentari foto Anda.', 
                       NOW(), 
                       0
                   )";
    mysqli_query($con, $notifQuery);

    // Komentar berhasil ditambahkan, kembali ke halaman detail foto
    header("Location: detailfoto.php?fotoID=$fotoID");
    exit();
} else {
    die("Terjadi kesalahan saat menambahkan komentar.");
}
?>
