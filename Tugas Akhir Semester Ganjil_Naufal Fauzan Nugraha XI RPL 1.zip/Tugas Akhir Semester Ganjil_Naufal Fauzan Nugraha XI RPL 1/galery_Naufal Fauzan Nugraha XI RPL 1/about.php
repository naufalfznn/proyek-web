<?php
session_start();
include "koneksi.php"; 


// Periksa apakah pengguna sudah login
$isLoggedIn = isset($_SESSION['UserID']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Snapict</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/nav.css">

    <style>
    body{
        font-family: 'Poppins', sans-serif;
    }

.hero-header {
    position: relative;
    background: url('image/bg.png') no-repeat center center/cover;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    color: #f5f5f5;
}

.hero-content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
}

.hero-content h2 {
    font-size: 3.5em;
    margin-bottom: 20px;
    text-transform: uppercase;
    font-weight: 700;
    letter-spacing: 3px;
    text-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
    border-right: none; /* Tidak perlu efek kursor */
    display: inline-block;
}


/* Greeting Text */
.hero-content .greeting {
    font-size: 1.5em;
    color: #ffffff;
    font-weight: 600;
    margin-bottom: 10px;
    animation: fadeIn 1.5s ease-in-out;
}

.hero-content .greeting span {
    font-style: italic;
    color: #1abc9c;
}

/* Tagline Animation */
.hero-content .tagline {
    font-size: 1.2em;
    color: #dcdcdc;
    font-weight: 400;
    margin-top: 10px;
    margin-bottom: 15px;
    animation: slideIn 2s ease-in-out;
}

/* Subtext */
.hero-content .subtext {
    font-size: 1.1em;
    color: #b3b3b3;
    font-weight: 300;
    margin-top: 20px;
    animation: fadeIn 2.5s ease-in-out;
}

/* Animasi Fade-In */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Animasi Slide-In */
@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateX(-30px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

/* Responsive Design */
@media (max-width: 768px) {
    .hero-content {
        padding: 30px 15px;
    }

    .hero-content h2 {
        font-size: 2.5em;
    }

    .hero-content .tagline, 
    .hero-content .subtext {
        font-size: 1em;
    }

    .hero-content .greeting {
        font-size: 1.2em;
    }
}


        .about-section {
    padding: 60px 0;
    background-color: #000000;
}

.container {
    width: 80%;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.about-text {
    width: 50%;
    padding-right: 40px;
}

.about-text h3 {
    font-size: 28px;
    font-weight: bold;
    color: #d8d8d8;
    margin-bottom: 20px;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.about-text p {
    font-size: 16px;
    line-height: 1.6;
    color: #ffffff;
    margin-bottom: 20px;
}

.about-image {
    width: 45%;
}

.about-image img {
    width: 100%;
    height: auto;
    border-radius: 10px;
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
}

/* Responsiveness */
@media screen and (max-width: 768px) {
    .container {
        flex-direction: column;
        align-items: center;
    }

    .about-text {
        width: 100%;
        padding-right: 0;
        margin-bottom: 30px;
    }

    .about-image {
        width: 80%;
    }
}

    /* Footer */
    footer {
        text-align: center;
        padding: 20px;
        background-color: #000000;
        color: #f5f5f5;
    }
    </style>
        
</head>
<body>
<header class="hero-header">
    <nav class="navbar">
        <div class="logo">
            <img src="image/LOGO.png" alt="logo">
        </div>
        <ul class="nav-links">
            <li><a href="dashboard.php" class="nav-item">Home</a></li>
            <li><a href="about.php" class="nav-item  active">About</a></li>
            <li><a href="gallery.php" class="nav-item">Gallery</a></li>
            <li><a href="contact.php" class="nav-item">Contact</a></li>
        </ul>
        <div>
            <?php if ($isLoggedIn): ?>
                <a href="profile.php" class="btn user-icon">
                    <i class="bi bi-person-circle"></i>
                    <?php echo htmlspecialchars($_SESSION['Username'], ENT_QUOTES, 'UTF-8'); ?>
                </a>
            <?php else: ?>
                <a href="login.php" class="btn btn-outline-primary">
                    Sign In/Up
                </a>
            <?php endif; ?>
        </div>
    </nav>
    <div class="hero-content">
        <h2>About Snapict</h2>
        <h4>Memberdayakan kreativitas melalui fotografi yang menakjubkan</h4>
    </div>
    
</header>
    
<main>
    <section id="about-us" class="about-section">
        <div class="container">
            <div class="about-text">
                <h3>Apa itu Snapict?</h3>
                <p>Snapict adalah platform dinamis yang didedikasikan untuk memamerkan fotografi yang menakjubkan dari berbagai tema. Baik Anda seorang fotografer profesional atau penggemar, Snapict menawarkan ruang untuk membuat, menangkap, dan merayakan keindahan kehidupan dalam setiap jepretan. Galeri kami menampilkan koleksi-koleksi menakjubkan mulai dari alam dan satwa liar hingga fotografi makanan, pemandangan kota, dan masih banyak lagi.</p>
                <h3>Misi Kami</h3>
                <p>Di Snapict, kami percaya pada kekuatan cerita visual. Misi kami adalah menginspirasi dan memberdayakan orang dengan menyediakan platform untuk berbagi momen-momen paling menarik mereka dengan dunia. Kami berusaha untuk menghubungkan kreator dari berbagai latar belakang hidup melalui seni fotografi, mendorong terciptanya komunitas global yang terdiri dari para penggemar dan profesional fotografi.</p>
                <h3>Visi Kami</h3>
                <p>Visi kami adalah untuk menjadi pusat utama bagi para penggemar fotografi, fotografer, dan kreator di seluruh dunia. Kami bertujuan untuk menciptakan lingkungan inklusif di mana bakat diakui, kreativitas dirayakan, dan setiap jepretan memiliki cerita untuk diceritakan.</p>
            </div>
            <div class="about-image">
                <img src="image/logoabt.png" alt="Snapict About Image">
            </div>
        </div>
    </section>
</main>

<footer>
    <p>&copy; 2025 Snapict. All Rights Reserved.</p>
</footer>
    
  
</body>
</html>
