<?php
session_start();
include "koneksi.php";

$isLoggedIn = isset($_SESSION['UserID']);
$userID = $isLoggedIn ? $_SESSION['UserID'] : null;

$isAdmin = false;
$role = '';
$error = ''; // Variabel untuk error
$success = ''; // Variabel untuk sukses

if ($isLoggedIn) {
    $query = "SELECT role.RoleName FROM user 
              INNER JOIN role ON user.RoleID = role.RoleID
              WHERE user.UserID = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $row = $result->fetch_assoc()) {
        $role = $row['RoleName'];
        $_SESSION['role'] = $role;
        $isAdmin = (strtolower($role) === 'admin');
    }
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    if (!$isLoggedIn) {
        $error = "Anda harus login terlebih dahulu untuk mengirim pesan.";
    } else {
        $name = $con->real_escape_string($_POST['name']);
        $email = $con->real_escape_string($_POST['email']);
        $subject = $con->real_escape_string($_POST['subject']);
        $message = $con->real_escape_string($_POST['message']);

        $query = "INSERT INTO messages (UserID, Name, Email, Subject, Message) 
                  VALUES (?, ?, ?, ?, ?)";
        $stmt = $con->prepare($query);
        $stmt->bind_param("issss", $userID, $name, $email, $subject, $message);

        if ($stmt->execute()) {
            $success = "Pesan Anda berhasil dikirim!";
        } else {
            $error = "Terjadi kesalahan saat mengirim pesan. Silakan coba lagi.";
        }
        $stmt->close();
    }
}

// Ambil semua pesan jika admin
$messages = $isAdmin ? $con->query("SELECT * FROM messages ORDER BY CreatedAt DESC") : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact & Messages</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/nav.css">
    <style>
         /* Mengatur body agar mengisi seluruh layar */
body {
    font-family: 'Poppins', sans-serif;
    background-color: #000; /* Latar belakang hitam */
    color: #f5f5f5; /* Teks putih */
    padding-top: 80px;
    padding-bottom: 80px;
    margin: 0; /* Menghilangkan margin default */
    position: relative;
    min-height: 100vh; /* Mengisi seluruh tinggi layar */
}

/* Menjaga footer tetap di bawah */
footer {
    position: absolute;
    bottom: 0;
    width: 100%;
    text-align: center;
    padding: 20px;
    background-color: #000;
    color: #f5f5f5;
}


        /* Card */
        .card {
            background: #1c1c1c;
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
            padding: 20px;
        }

        /* Button */
        .btn-primary {
            background: #16a085;
            border: none;
            color: #fff;
        }

        .btn-primary:hover {
            background: #16a085;
        }

        /* Form */
        .form-control {
            background-color: #222; /* Latar belakang input */
            color: #f5f5f5; /* Teks terang */
            border: 1px solid #16a085; /* Warna hijau */
            border-radius: 8px;
        }

        .form-control::placeholder {
            color:rgb(0, 0, 0); /* Placeholder abu-abu terang */
        }

        .form-control:focus {
            background-color: #333; /* Fokus lebih terang */
            color: #fff; /* Teks tetap putih */
            border-color: #16a085; /* Warna hijau */
            box-shadow: 0 0 10px rgba(46, 204, 113, 0.5); /* Efek fokus hijau */
        }

        /* Table */
        .table {
            color: #fff;
            background: #1e1e1e;
        }

        .table th {
            background-color: #16a085;
            color: #fff;
            border: none;
        }

        .table tr:hover {
            background: rgba(46, 204, 113, 0.1);
        }

        .table-bordered {
            border: 1px solid #444;
        }

        /* Alerts */
        .alert {
            border-radius: 12px;
            background-color: #222;
            color: #16a085; /* Warna hijau */
            font-size: 1.1rem;
        }

        /* Titles */
        h1 {
            color: #16a085;
            font-size: 2.8rem;
            margin-bottom: 20px;
        }

        /* Placeholder untuk semua input */
        input::placeholder,
        textarea::placeholder {
            color: #9e9e9e;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
<header class="hero-header">
    <nav class="navbar">
        <div class="logo">
            <img src="image/LOGO.png" alt="logo">
        </div>
        <ul class="nav-links">
            <li><a href="dashboard.php" class="nav-item">Home</a></li>
            <li><a href="about.php" class="nav-item">About</a></li>
            <li><a href="gallery.php" class="nav-item">Gallery</a></li>
            <li><a href="contact.php" class="nav-item active">Contact</a></li>
        </ul>
        <div>
            <?php if ($isLoggedIn): ?>
                <a href="profile.php" class="btn user-icon">
                    <i class="bi bi-person-circle"></i>
                    <?php echo htmlspecialchars($_SESSION['Username'], ENT_QUOTES, 'UTF-8'); ?>
                </a>
            <?php else: ?>
                <a href="login.php" class="btn btn-outline-primary">
                    Sign In/Up
                </a>
            <?php endif; ?>
        </div>
    </nav>
</header>
<div class="container mt-5">
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php elseif ($success): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <?php if ($isAdmin): ?>
        <!-- Tampilan Admin -->
        <h1>Pesan Masuk</h1>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Subjek</th>
                    <th>Pesan</th>
                    <th>Tanggal</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($messages && $messages->num_rows > 0): ?>
                    <?php while ($row = $messages->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['MessageID']; ?></td>
                            <td><?php echo htmlspecialchars($row['Name']); ?></td>
                            <td><?php echo htmlspecialchars($row['Email']); ?></td>
                            <td><?php echo htmlspecialchars($row['Subject']); ?></td>
                            <td><?php echo htmlspecialchars($row['Message']); ?></td>
                            <td><?php echo htmlspecialchars($row['CreatedAt']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">Tidak ada pesan.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    <?php else: ?>
        <!-- Tampilan User -->
        <h1>Contact Us</h1>
        <form method="POST">
            <div class="mb-3">
                <label for="name" class="form-label">Nama</label>
                <input type="text" name="name" id="name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" id="email" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="subject" class="form-label">Subjek</label>
                <input type="text" name="subject" id="subject" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="message" class="form-label">Pesan</label>
                <textarea name="message" id="message" rows="5" class="form-control" required></textarea>
            </div>
            <button type="submit" name="send_message" class="btn btn-primary">Kirim</button>
        </form>
    <?php endif; ?>
</div>
<footer>
    <p>&copy; 2025 Snapict. All Rights Reserved.</p>
</footer>
</body>
</html>
