<?php
session_start();

if (!isset($_SESSION['UserID'])) {
    echo "UserID tidak ditemukan dalam session!";
    exit();
}

include 'koneksi.php'; 

// Proses upload foto
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $judul = $_POST['judul'];
    $deskripsi = $_POST['deskripsi'];
    $tanggal = $_POST['tanggal'];
    $albumID = $_POST['album'];
    $foto = $_FILES['foto'];

    // Menyimpan file foto ke folder uploads
    $targetDir = "uploads/";
    $targetFile = $targetDir . basename($foto["name"]);

    // Pindahkan file ke folder uploads
    move_uploaded_file($foto["tmp_name"], $targetFile);

    // Hanya simpan nama file tanpa path di database
    $fileName = basename($foto["name"]); // Ambil nama file saja

    // Menyimpan informasi foto ke database
    $UserID = $_SESSION['UserID'];
    $query = "INSERT INTO foto (JudulFoto, DeskripsiFoto, TanggalUnggah, LokasiFoto, AlbumID, UserID) 
              VALUES ('$judul', '$deskripsi', '$tanggal', '$fileName', '$albumID', '$UserID')";

    // Menjalankan query untuk menyimpan foto ke database
    if (mysqli_query($con, $query)) {
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Terjadi kesalahan: " . mysqli_error($con);
    }
}
?>
