<?php
try {
    $db = new PDO("mysql:host=localhost;dbname=gallerydb_", "root", "");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi gagal: " . $e->getMessage());
}

// Ambil daftar role dari database
$roles = [];
try {
    $stmt = $db->query("SELECT RoleID, RoleName FROM role");
    $roles = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error saat mengambil data role: " . $e->getMessage());
}

if (isset($_POST['register'])) {
    // Validasi input
    $NamaLengkap = filter_input(INPUT_POST, 'NamaLengkap', FILTER_SANITIZE_SPECIAL_CHARS);
    $Username = filter_input(INPUT_POST, 'Username', FILTER_SANITIZE_SPECIAL_CHARS);
    $Email = filter_input(INPUT_POST, 'Email', FILTER_VALIDATE_EMAIL);
    $Password = isset($_POST["Password"]) ? md5($_POST["Password"]) : null;
    $Alamat = filter_input(INPUT_POST, 'Alamat', FILTER_SANITIZE_SPECIAL_CHARS);
    $RoleID = filter_input(INPUT_POST, 'RoleID', FILTER_VALIDATE_INT);

    if (!$NamaLengkap || !$Username || !$Email || !$Password || !$Alamat || !$RoleID) {
        die("Semua field wajib diisi dan valid!");
    }

    // Simpan data ke database
    $sql = "INSERT INTO user (NamaLengkap, Username, Email, Password, Alamat, RoleID) 
            VALUES (:NamaLengkap, :Username, :Email, :Password, :Alamat, :RoleID)";
    $stmt = $db->prepare($sql);

    $params = [
        ":NamaLengkap" => $NamaLengkap,
        ":Username" => $Username,
        ":Email" => $Email,
        ":Password" => $Password,
        ":Alamat" => $Alamat,
        ":RoleID" => $RoleID,
    ];

    try {
        $saved = $stmt->execute($params);
        if ($saved) {
            header("Location: login.php"); 
            exit();
        } else {
            echo "Terjadi kesalahan saat menyimpan data.";
        }
    } catch (PDOException $e) {
        die("Error saat menyimpan data: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Registrasi</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
    body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 50px 0; /* Ruang atas dan bawah */
    background-color:rgb(255, 255, 255);
    color: #f5f5f5;
    display: flex;
    justify-content: center; /* Tengah horizontal */
    align-items: center; /* Tengah vertikal */
    min-height: 100vh; /* Pastikan body memenuhi tinggi layar */
}

.register-container {
    width: 100%;
    max-width: 600px;
    padding: 20px;
    box-sizing: border-box;
}

    /* Form Styling */
    .register-form {
        background-color: #1a1a1a;
        padding: 50px 40px;
        border-radius: 12px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.6);
        width: 100%;
        text-align: center;
    }

    .register-form h3 {
        font-size: 2em;
        color: #16a085;
        margin-bottom: 30px;
    }

    .register-form label {
        font-size: 1em;
        color: #dcdcdc;
        margin-bottom: 8px;
        display: block;
        text-align: left; /* Label sejajar di kiri */
    }

    .register-form input,
    .register-form select,
    .register-form textarea {
        width: 100%; /* Maksimalkan lebar input */
        padding: 12px 15px;
        margin-bottom: 20px;
        border-radius: 8px;
        border: 1px solid #ccc;
        background-color: #333;
        color: #f5f5f5;
        font-size: 1em;
        outline: none;
        text-align: left; /* Placeholder sejajar kiri */
        box-sizing: border-box; /* Pastikan padding tidak melanggar lebar */
        transition: border 0.3s ease, background-color 0.3s ease;
    }

    .register-form input:focus,
    .register-form select:focus,
    .register-form textarea:focus {
        border-color: #16a085;
        background-color: #444;
    }

    .register-form textarea {
        resize: none;
    }

    /* Tombol dengan Animasi */
    .register-form button {
        width: 100%;
        padding: 14px 16px;
        background-color: #16a085;
        color: #ffffff;
        border: none;
        border-radius: 8px;
        font-size: 1.2em;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
    }

    .register-form button:hover {
        background-color: #1abc9c;
        transform: translateY(-3px);
        box-shadow: 0 6px 15px rgba(0, 255, 128, 0.5);
    }

    /* Login Link */
    .register-form .login-link {
        font-size: 0.9em;
        color: #cccccc;
        margin-top: 15px;
    }

    .register-form .login-link a {
        color: #16a085;
        text-decoration: none;
        transition: color 0.3s ease;
    }

    .register-form .login-link a:hover {
        color: #ffffff;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .register-form {
            padding: 30px 20px;
        }

        .register-form h3 {
            font-size: 1.8em;
        }

        .register-form input,
        .register-form button {
            font-size: 1em;
        }
    }
</style>

</head>
<body>
    <div class="register-container">
        <form class="register-form" method="POST" action="">
            <h3>Sign Up</h3>
            
            <label for="fullname">Nama Lengkap</label>
            <input type="text" id="fullname" name="NamaLengkap" placeholder="Nama Lengkap" required>
            
            <label for="Username">Username</label>
            <input type="text" id="Username" name="Username" placeholder="Username" required>
            
            <label for="role">Role</label>
            <select id="role" name="RoleID" required>
                <option value="" disabled selected>Pilih Role</option>
                <?php foreach ($roles as $role): ?>
                    <option value="<?= htmlspecialchars($role['RoleID']) ?>"><?= htmlspecialchars($role['RoleName']) ?></option>
                <?php endforeach; ?>
            </select>
            
            <label for="email">Email</label>
            <input type="email" id="email" name="Email" placeholder="Alamat Email" required>
            
            <label for="password">Password</label>
            <input type="password" id="password" name="Password" placeholder="Password" required>
            
            <label for="address">Alamat</label>
            <textarea id="address" name="Alamat" placeholder="Alamat Lengkap" rows="3" required></textarea>
            
            <button type="submit" name="register">Daftar</button>
            <p class="login-link">
                Sudah punya akun? <a href="login.php">Login</a>.
            </p>
        </form>
    </div>
</body>
</html>
