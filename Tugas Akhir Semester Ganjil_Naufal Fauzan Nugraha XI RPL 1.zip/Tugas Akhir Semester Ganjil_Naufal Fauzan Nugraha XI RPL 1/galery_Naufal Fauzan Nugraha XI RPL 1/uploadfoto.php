<?php
session_start();
include "koneksi.php";

// Pastikan user sudah login
if (!isset($_SESSION['Username'])) {
    header("Location: login.php"); 
    exit();
}

$isLoggedIn = isset($_SESSION['UserID']) && !empty($_SESSION['UserID']);
$userID = $isLoggedIn ? $_SESSION['UserID'] : null;

// Proses upload
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $judul = $_POST['judul'];
    $deskripsi = $_POST['deskripsi'];
    $tanggal = $_POST['tanggal'];
    $albumID = $_POST['album'];
    $userID = $_SESSION['UserID'];

    // Proses upload file
    $foto = $_FILES['foto'];
    $fileName = $foto['name'];
    $fileTmp = $foto['tmp_name'];

    // Lokasi upload
    $uploadDir = 'uploads/';
    $uploadFile = $uploadDir . basename($fileName);

    if (move_uploaded_file($fileTmp, $uploadFile)) {
        // Simpan data ke database
        $query = "INSERT INTO foto (JudulFoto, DeskripsiFoto, TanggalUnggah, LokasiFoto, AlbumID, UserID) 
                  VALUES ('$judul', '$deskripsi', '$tanggal', '$fileName', '$albumID', '$userID')";
        if (mysqli_query($con, $query)) {
            echo "<script>alert('Foto berhasil diunggah!'); window.location.href='dashboard.php';</script>";
        } else {
            echo "<script>alert('Gagal menyimpan data ke database!');</script>";
        }
    } else {
        echo "<script>alert('Gagal mengunggah file!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Foto</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/nav.css">
    <style>

/* Konten Utama */
.container {
    flex: 1; 
}

/* Footer */
footer {
    text-align: center;
    background-color:rgb(0, 0, 0);
    color:rgb(255, 255, 255);
    padding: 10px 0;
    box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.2); 
    margin-top: auto; 
}

        /* Body */
        body {
    font-family: 'Poppins', sans-serif;
    background-color: #000 !important;
    color:rgb(255, 255, 255); 
    margin-top: 100px;
    display: flex;
    flex-direction: column;
    min-height: 100vh; 
    background: #000000;
}


        .album-input-container {
            margin: 50px auto;
            padding: 20px;
            max-width: 400px;
            background-color: rgba(0, 0, 0, 0.8);
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
            text-align: center;
        }

        .album-input-container h2 {
            font-size: 28px;
            color: #16a085;
            margin-bottom: 20px;
        }

        .album-input-container label {
            font-size: 16px;
            color: #f5f5f5;
            text-align: left;
            display: block;
            margin-bottom: 5px;
        }

        .album-input-container input,
        .album-input-container textarea {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            background: rgba(255, 255, 255, 0.1);
            border: none;
            color: #f5f5f5;
            margin-bottom: 15px;
            font-size: 14px;
        }

        .album-input-container button {
            width: 50%;
            padding: 10px;
            border-radius: 30px;
            background: #16a085;
            border: none;
            color: #fff;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .album-input-container button:hover {
            background: #13a077;
        }

        /* Styling untuk link kembali ke dashboard */
        .album-input-container a {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color:rgb(255, 255, 255);
            font-weight: 600;
            margin-top: 40px;
        }

        .album-input-container a:hover {
            color: #13a077;
        }

        /* Styling untuk dropdown album */
    .album-input-container select {
        width: 100%;
        padding: 10px;
        border-radius: 5px;
        background: rgba(255, 255, 255, 0.1); 
        border: none;
        color: #f5f5f5;
        font-size: 14px;
        margin-bottom: 15px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .album-input-container select:hover {
        background-color: rgba(255, 255, 255, 0.2);
    }

    /* Styling saat dropdown terbuka */
    .album-input-container select:focus {
        background: rgba(22, 160, 133, 0.2); 
        color: #fff;
    }

    /* Styling untuk opsi yang dipilih */
    .album-input-container option {
        background-color: #333; 
        color: #f5f5f5; 
    }

    /* Styling saat opsi dipilih */
    .album-input-container select option:checked {
        background-color: #16a085; 
        color: #fff;
    }

    /* Background kontainer utama */
.album-input-container {
    background-color: #000; /* Hitam */
    color: #fff; /* Teks putih */
}

/* Styling dropdown (untuk memastikan konsistensi) */
.album-input-container select {
    background: rgba(0, 0, 0, 0.8); /* Hitam pekat */
    color: #fff;
}

.album-input-container select option {
    background-color: #000; /* Hitam */
    color: #fff;
}


    </style>
</head>
<header class="hero-header">
    <nav class="navbar">
        <div class="logo">
            <img src="image/LOGO.png" alt="logo">
            <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
        </div>
        <ul class="nav-links">
            <li><a href="dashboard.php" class="nav-item">Home</a></li>
            <li><a href="about.php" class="nav-item">About</a></li>
            <li><a href="gallery.php" class="nav-item">Gallery</a></li>
            <li><a href="contact.php" class="nav-item">Contact</a></li>
        </ul>
        <div>
            <?php if ($isLoggedIn): ?>
                <a href="profile.php" class="btn user-icon">
                    <i class="bi bi-person-circle"></i>
                    <?php echo htmlspecialchars($_SESSION['Username'], ENT_QUOTES, 'UTF-8'); ?>
                </a>
            <?php else: ?>
                <a href="login.php" class="btn btn-outline-primary">
                    Sign In/Up
                </a>
            <?php endif; ?>
        </div>
    </nav>
</header>

<body>
    <div class="album-input-container">
        <h2>Unggah Foto Baru</h2>
        <form action="uploadfoto.php" method="POST" enctype="multipart/form-data">
            <div>
                <label for="judul">Judul Foto:</label>
                <input type="text" id="judul" name="judul" placeholder="Masukkan judul foto" required>
            </div>
            <div>
                <label for="deskripsi">Deskripsi Foto:</label>
                <textarea id="deskripsi" name="deskripsi" rows="4" placeholder="Masukkan deskripsi foto" required></textarea>
            </div>
            <div>
                <label for="tanggal">Tanggal Unggah:</label>
                <input type="date" id="tanggal" name="tanggal" required>
            </div>
            <div>
                <label for="foto">Upload Foto:</label>
                <input type="file" id="foto" name="foto" required>
            </div>
            <div>
                <label for="album">Album:</label>
                <select name="album" id="album" required>
                    <?php
                    // Ambil data album dari database
                    $query = "SELECT * FROM album";
                    $result = mysqli_query($con, $query);
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<option value='{$row['AlbumID']}'>{$row['NamaAlbum']}</option>";
                    }
                    ?>
                </select>
            </div>
            <button type="submit">Upload Foto</button>
        </form>
        <a href="dashboard.php">Kembali ke Dashboard</a>
    </div>
    <footer>
    <p>&copy; 2025 Snapict. All Rights Reserved.</p>
</footer>
</body>
</html>
