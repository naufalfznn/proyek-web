<?php
$con = mysqli_connect("localhost", "root", "", "gallerydb_");
?>