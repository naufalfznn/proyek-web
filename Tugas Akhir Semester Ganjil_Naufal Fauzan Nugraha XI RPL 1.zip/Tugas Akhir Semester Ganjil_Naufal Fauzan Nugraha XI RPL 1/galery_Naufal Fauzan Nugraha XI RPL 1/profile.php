<?php
session_start();
include "koneksi.php";

// Periksa apakah pengguna sudah login
$isLoggedIn = isset($_SESSION['UserID']);
$userID = $isLoggedIn ? $_SESSION['UserID'] : null;

// Ambil data pengguna dari database jika sudah login
$user = null;
if ($isLoggedIn) {
    $stmt = $con->prepare("SELECT u.Username, u.Email, u.NamaLengkap, u.Alamat, r.RoleName FROM user u LEFT JOIN role r ON u.RoleID = r.RoleID WHERE u.UserID = ?");
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $row = $result->fetch_assoc()) {
        $user = $row;
    } else {
        echo "<p>Data pengguna tidak ditemukan.</p>";
        exit();
    }
    $stmt->close();

    // Ambil data foto yang diunggah oleh pengguna
    $stmtFoto = $con->prepare("SELECT f.FotoID, f.JudulFoto, f.DeskripsiFoto, f.TanggalUnggah, f.LokasiFoto, a.NamaAlbum FROM foto f LEFT JOIN album a ON f.AlbumID = a.AlbumID WHERE f.UserID = ?");
    $stmtFoto->bind_param("i", $userID);
    $stmtFoto->execute();
    $resultFoto = $stmtFoto->get_result();
    $userFotos = [];
    while ($foto = $resultFoto->fetch_assoc()) {
        $userFotos[] = $foto;
    }
    $stmtFoto->close();
}

// Tangani penghapusan foto
if (isset($_POST['delete']) && isset($_POST['foto_id'])) {
    $fotoID = intval($_POST['foto_id']);

    // Ambil lokasi file foto untuk dihapus dari folder
    $stmt = $con->prepare("SELECT LokasiFoto FROM foto WHERE FotoID = ? AND UserID = ?");
    $stmt->bind_param("ii", $fotoID, $userID);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $row = $result->fetch_assoc()) {
        $filePath = "uploads/" . $row['LokasiFoto'];

        // Hapus file dari folder
        if (file_exists($filePath)) {
            unlink($filePath);
        }

        // Hapus data foto dari database
        $stmtDelete = $con->prepare("DELETE FROM foto WHERE FotoID = ? AND UserID = ?");
        $stmtDelete->bind_param("ii", $fotoID, $userID);
        $stmtDelete->execute();
        $stmtDelete->close();

        // Redirect untuk memperbarui tampilan
        header("Location: profile.php");
        exit();
    }
    $stmt->close();
}

// Proses logout
if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Pengguna</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/nav.css">
    <style>
/* Mengatur body agar mengisi seluruh layar */
body {
    font-family: 'Poppins', sans-serif;
    background-color: #000; /* Latar belakang hitam */
    color: #f5f5f5; /* Teks putih */
    padding-top: 80px;
    padding-bottom: 80px;
    margin: 0; /* Menghilangkan margin default */
    position: relative;
    min-height: 100vh; /* Mengisi seluruh tinggi layar */
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    flex: 1;
}

/* Header */
.profile-header {
    text-align: center;
    margin-bottom: 50px;
}

.profile-header h1 {
    font-size: 3em;
    font-weight: 700;
    background: linear-gradient(90deg, #16a085, #1abc9c);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

/* Profile Card Styling */
.profile-card {
    background-color: #000; /* Hitam */
    border: 2px solid #fff; /* Border putih */
    border-radius: 20px;
    padding: 20px;
    margin-bottom: 40px;
    color: #f5f5f5; /* Teks putih */
    position: relative;
}

.profile-card h3 {
    font-size: 1.8em;
    color: #16a085; /* Hijau */
    margin-bottom: 15px;
}

.profile-card p {
    font-size: 1.1em;
    margin-bottom: 10px;
}

.profile-card p i {
    color: #16a085; /* Hijau */
    margin-right: 8px;
}

/* Tombol Logout */
.btn-logout {
    position: absolute;
    top: 20px;
    right: 20px;
    background: #16a085; /* Hijau */
    color: #000; /* Teks hitam */
    font-weight: 600;
    border-radius: 15px;
    padding: 8px 15px;
    font-size: 0.9em;
    border: none;
    transition: background 0.3s ease, transform 0.3s ease;
}

.btn-logout:hover {
    background: #128f76; /* Hijau lebih gelap */
    transform: scale(1.05);
}

/* Photo Grid */
.photo-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 50px;
}

/* Card Container */
.photo-card {
    background-color: #1a1a1a; /* Hitam */
    color: #f5f5f5;
    border: none;
    border-radius: 10px; /* Sesuai referensi */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3); /* Efek bayangan */
    transition: box-shadow 0.3s ease, transform 0.3s ease;
}

.photo-card:hover {
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.6); /* Bayangan lebih besar saat hover */
}

/* Image */
.photo-card img {
    transition: transform 0.3s ease, filter 0.3s ease;
    filter: brightness(1.2); /* Kecerahan awal */
    width: 100%; /* Sesuai referensi */
    height: auto;
}

.photo-card:hover img {
    transform: scale(1.05); /* Perbesar saat hover */
    filter: brightness(0.8); /* Kurangi kecerahan saat hover */
}

/* Card Body */
.photo-card .card-body {
    padding: 15px;
    text-align: center; /* Pastikan konten tengah */
}

/* Judul Foto */
.photo-card .card-body h5 {
    text-align: center; /* Judul di tengah */
    color: #ffffff; /* Putih */
    font-size: 1.2em;
    margin-bottom: 10px;
}

/* Deskripsi Foto */
.photo-card .card-body p {
    text-align: left; /* Deskripsi di kiri */
    font-size: 0.9em; /* Ukuran teks lebih kecil */
    color: #aaa; /* Abu-abu terang */
    margin-bottom: 15px;
}

/* Tombol */
.photo-card .btn-details,
.photo-card .btn-delete {
    display: inline-block; /* Agar bisa diatur tata letaknya */
    background-color: #16a085; /* Hijau */
    color: #fff;
    border: none;
    padding: 10px 15px; /* Padding tombol */
    border-radius: 5px;
    font-size: 0.9em;
    text-transform: uppercase;
    text-decoration: none; /* Hilangkan garis bawah */
    margin: 5px 5px; /* Jarak antar tombol */
    transition: background-color 0.3s ease, transform 0.3s ease;
}

/* Tombol Hover */
.photo-card .btn-details:hover {
    background-color: #13a57c;
    transform: scale(1.05);
}

.photo-card .btn-delete {
    background-color: #e74c3c; /* Merah */
}

.photo-card .btn-delete:hover {
    background-color: #c0392b; /* Merah lebih gelap */
    transform: scale(1.05);
}

/* Tata Letak Tombol */
.photo-card .card-body .btn-container {
    display: flex;
    justify-content: center; /* Tengah secara horizontal */
    gap: 10px; /* Jarak antar tombol */
}
/* Menjaga footer tetap di bawah */
footer {
    position: absolute;
    bottom: 0;
    width: 100%;
    text-align: center;
    padding: 20px;
    background-color: #000;
    color: #f5f5f5;
}
    </style>
</head>
<body>
<header class="hero-header">
    <nav class="navbar">
        <div class="logo">
            <img src="image/LOGO.png" alt="logo">
        </div>
        <ul class="nav-links">
            <li><a href="dashboard.php" class="nav-item">Home</a></li>
            <li><a href="about.php" class="nav-item">About</a></li>
            <li><a href="gallery.php" class="nav-item">Gallery</a></li>
            <li><a href="contact.php" class="nav-item">Contact</a></li>
        </ul>
        <div>
            <?php if ($isLoggedIn): ?>
                <a href="profile.php" class="btn user-icon">
                    <i class="bi bi-person-circle"></i>
                    <?php echo htmlspecialchars($user['Username']); ?>
                </a>
            <?php else: ?>
                <a href="login.php" class="btn user-icon">
                    <i class="bi bi-person-circle"></i>
                </a>
            <?php endif; ?>
        </div>
    </nav>
</header>

    <div class="container">
        <div class="profile-header">
            <h1>Profil Pengguna</h1>
        </div>

        <?php if ($isLoggedIn): ?>
            <!-- Profile Card -->
            <div class="profile-card">
                <h3>&nbsp;&nbsp;Informasi Pengguna</h3>
                <p><i class="bi bi-person"></i> <strong>Nama :</strong> <?php echo htmlspecialchars($user['NamaLengkap']); ?></p>
                <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>Username :</strong> <?php echo htmlspecialchars($user['Username']); ?></p>
                <p><i class="bi bi-envelope"></i> <strong>Email :</strong> <?php echo htmlspecialchars($user['Email']); ?></p>
                <p><i class="bi bi-house-door"></i> <strong>Alamat :</strong> <?php echo htmlspecialchars($user['Alamat']); ?></p>
                <p><i class="bi bi-award"></i> <strong>Role :</strong> <?php echo htmlspecialchars($user['RoleName']); ?></p>
                <form method="POST">
                    <button type="submit" name="logout" class="btn-logout">Logout</button>
                </form>
            </div>

            <!-- Photos Grid -->
            <h3>Foto yang Diunggah</h3>
            <?php if (count($userFotos) > 0): ?>
                <div class="photo-grid">
                    <?php foreach ($userFotos as $foto): ?>
                        <div class="photo-card">
                            <img src="uploads/<?php echo htmlspecialchars($foto['LokasiFoto']); ?>" alt="<?php echo htmlspecialchars($foto['JudulFoto']); ?>">
                            <div class="card-body">
                                <h5><?php echo htmlspecialchars($foto['JudulFoto']); ?></h5>
                                <p><?php echo htmlspecialchars($foto['DeskripsiFoto']); ?></p>
                                <p><strong>Album :</strong> <?php echo htmlspecialchars($foto['NamaAlbum']); ?></p>
                                <p><strong>Tanggal Unggah :</strong> <?php echo htmlspecialchars($foto['TanggalUnggah']); ?></p>
                                <a href="detailfoto.php?fotoID=<?php echo $foto['FotoID']; ?>" class="btn-details">Lihat Detail</a>
                                <form method="POST" style="display:inline-block;">
                                    <input type="hidden" name="foto_id" value="<?php echo $foto['FotoID']; ?>">
                                    <button type="submit" name="delete" class="btn-delete">Hapus</button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>Anda belum mengunggah foto apa pun.</p>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <footer>
    <p>&copy; 2025 Snapict. All Rights Reserved.</p>
</footer>

</body>
</html>