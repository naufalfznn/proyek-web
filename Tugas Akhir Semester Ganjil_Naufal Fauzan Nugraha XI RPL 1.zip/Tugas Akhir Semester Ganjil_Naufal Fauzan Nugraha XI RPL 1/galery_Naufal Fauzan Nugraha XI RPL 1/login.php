<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }


        /* Login Container */
        .login-container {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        /* Form Styling */
        .login-form {
            background-color: #1a1a1a;
            padding: 40px 30px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.5);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        .login-form h3 {
            font-size: 1.8em;
            color: #16a085;
            margin-bottom: 20px;
        }

        .login-form label {
            font-size: 1em;
            color: #dcdcdc;
            margin-bottom: 8px;
            text-align: left;
            display: block;
        }

        .login-form input {
            width: 92%;
            padding: 12px 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            border: 1px solid #ccc;
            background-color: #333;
            color: #f5f5f5;
            font-size: 1em;
            outline: none;
            transition: border 0.3s ease, background-color 0.3s ease;
        }

        .login-form input:focus {
            border-color: #16a085;
            background-color: #444;
        }

        /* Tombol dengan Animasi */
        .login-form button {
            width: 100%;
            padding: 12px 15px;
            background-color: #16a085;
            color: #ffffff;
            border: none;
            border-radius: 8px;
            font-size: 1.2em;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
        }

        .login-form button:hover {
            background-color: #1abc9c;
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(0, 255, 128, 0.5);
        }

        /* Register Link */
        .login-form .register-link {
            font-size: 0.9em;
            color: #cccccc;
            margin-top: 15px;
        }

        .login-form .register-link a {
            color: #16a085;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .login-form .register-link a:hover {
            color: #ffffff;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .login-form {
                padding: 30px 20px;
            }

            .login-form h3 {
                font-size: 1.5em;
            }

            .login-form input,
            .login-form button {
                font-size: 1em;
            }
        }
    </style>
</head>
<body>

    <div>
    <div class="login-container">
        <form class="login-form" action="ceklogin.php" method="POST">
            <h3>Login</h3>
            <label for="Username">Username</label>
            <input type="text" id="Username" name="Username" placeholder="Masukkan username">
            
            <label for="Password">Password</label>
            <input type="password" id="Password" name="Password" placeholder="Masukkan password">
            
            <button type="submit">Login</button>
            <p class="register-link">
                Belum punya akun? <a href="register.php">Sign Up</a>.
            </p>
        </form>
    </div>

        <!-- Pesan error jika login gagal -->
        <?php
        if (isset($_GET['error'])) {
            if ($_GET['error'] == 'empty') {
                echo "<p style='color: red;'>Form tidak lengkap. Pastikan Anda mengisi username dan password!</p>";
            } elseif ($_GET['error'] == 'invalid') {
                echo "<p style='color: red;'>Login gagal! Username atau password salah.</p>";
            }
        }
        ?>

    </div>

</body>
</html>
