<?php
session_start();
include "koneksi.php";

// Periksa apakah pengguna adalah Admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: dashboard.php");
    exit();
}

// Hapus foto
if (isset($_POST['delete'])) {
    $fotoID = intval($_POST['fotoID']);
    $query = "DELETE FROM foto WHERE FotoID = $fotoID";
    if (mysqli_query($con, $query)) {
        $message = "Foto berhasil dihapus.";
    } else {
        $message = "Gagal menghapus foto: " . mysqli_error($con);
    }
}

$isLoggedIn = isset($_SESSION['UserID']) && !empty($_SESSION['UserID']);
$userID = $isLoggedIn ? $_SESSION['UserID'] : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Foto</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/nav.css"> 
    <style>
/* Body */
body {
    font-family: 'Poppins', sans-serif;
    background-color: #000; /* Latar belakang hitam */
    color:rgb(255, 255, 255); /* Teks terang */
    margin-top: 125px;
    display: flex;
    flex-direction: column;
    min-height: 100vh; /* Pastikan body mengisi seluruh tinggi layar */
}

/* Konten Utama */
.container {
    flex: 1; /* Membuat konten utama mengisi sisa ruang */
}

/* Footer */
footer {
    text-align: center;
    background-color:rgb(0, 0, 0);
    color:rgb(255, 255, 255);
    padding: 10px 0;
    box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.2); /* Bayangan untuk footer */
    margin-top: auto; /* Memastikan footer berada di bawah konten */
}

/* Kartu (Card) */
.card {
    background-color: #1c1c1c; /* Warna dasar kartu */
    border: none; /* Tanpa border */
    border-radius: 12px; /* Sudut membulat */
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4); /* Bayangan */
    padding: 20px; /* Jarak dalam */
}

/* Tombol */
.btn-primary,
.btn-danger {
    background-color:rgb(255, 0, 0); /* Warna hijau utama */
    border: none; /* Tanpa border */
    color: #fff; /* Teks putih */
}

.btn-primary:hover,
.btn-danger:hover {
    background-color:rgb(165, 0, 0); /* Hijau yang lebih terang saat di-hover */
}

/* Tabel */
.table {
    color: #fff; /* Teks putih */
    background-color: #1e1e1e; /* Warna dasar tabel */
}

.table th {
    background-color: #16a085; /* Warna header tabel */
    color: #fff; /* Teks putih di header */
    border: none; /* Tanpa border */
}

.table tr:hover {
    background-color: rgba(46, 204, 113, 0.1); /* Efek hover pada baris */
}

table tr{
    padding-top: 5px;
}

.table-bordered {
    border: 1px solid #444; /* Border tabel */
}

/* Peringatan (Alert) */
.alert {
    border-radius: 12px; /* Sudut membulat */
    background-color: #222; /* Latar belakang gelap */
    color: #16a085; /* Teks hijau */
    font-size: 1.1rem; /* Ukuran teks */
}

/* Judul */
h1 {
    color: #16a085; /* Hijau */
    font-size: 2.8rem; /* Ukuran besar */
    margin-bottom: 20px; /* Jarak bawah */
}

    </style>
</head>
<header class="hero-header">
<nav class="navbar">
        <div class="logo">
            <img src="image/LOGO.png" alt="logo">
        </div>
        <ul class="nav-links">
            <li><a href="dashboard.php" class="nav-item">Home</a></li>
            <li><a href="about.php" class="nav-item">About</a></li>
            <li><a href="gallery.php" class="nav-item">Gallery</a></li>
            <li><a href="contact.php" class="nav-item ">Contact</a></li>
        </ul>
        <div>
            <?php if ($isLoggedIn): ?>
                <a href="profile.php" class="btn user-icon">
                    <i class="bi bi-person-circle"></i>
                    <?php echo htmlspecialchars($_SESSION['Username'], ENT_QUOTES, 'UTF-8'); ?>
                </a>
            <?php else: ?>
                <a href="login.php" class="btn btn-outline-primary">
                    Sign In/Up
                </a>
            <?php endif; ?>
        </div>
    </nav>
</header>
<body>
<div class="container mt-5">
    <h1>Kelola Foto</h1>
    <?php if (isset($message)): ?>
        <div class="alert alert-info"><?php echo $message; ?></div>
    <?php endif; ?>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>Judul Foto</th>
            <th>Deskripsi</th>
            <th>Album</th>
            <th>Tanggal Upload</th>
            <th>Jumlah Like</th>
            <th>Jumlah Komentar</th>
            <th>Pengupload</th>
            <th>Opsi</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $query = "SELECT foto.FotoID, foto.JudulFoto, foto.DeskripsiFoto, album.NamaAlbum, foto.TanggalUnggah, 
                         (SELECT COUNT(*) FROM likefoto WHERE likefoto.FotoID = foto.FotoID) AS jumlah_like,
                         (SELECT COUNT(*) FROM komentarfoto WHERE komentarfoto.FotoID = foto.FotoID) AS jumlah_komentar,
                         user.Username AS Pengupload
                  FROM foto
                  INNER JOIN album ON foto.AlbumID = album.AlbumID
                  INNER JOIN user ON foto.UserID = user.UserID";
        $result = mysqli_query($con, $query);
        while ($row = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['JudulFoto']); ?></td>
                <td><?php echo htmlspecialchars($row['DeskripsiFoto']); ?></td>
                <td><?php echo htmlspecialchars($row['NamaAlbum']); ?></td>
                <td><?php echo date('d-m-Y', strtotime($row['TanggalUnggah'])); ?></td> <!-- Menampilkan tanggal upload -->
                <td><?php echo $row['jumlah_like']; ?></td> <!-- Menampilkan jumlah like -->
                <td><?php echo $row['jumlah_komentar']; ?></td> <!-- Menampilkan jumlah komentar -->
                <td><?php echo htmlspecialchars($row['Pengupload']); ?></td> <!-- Menampilkan nama pengupload -->
                <td>
                    <form method="POST" onsubmit="return confirm('Hapus foto ini?')">
                        <input type="hidden" name="fotoID" value="<?php echo $row['FotoID']; ?>">
                        <button type="submit" name="delete" class="btn btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>

    <a href="dashboard.php" class="btn btn-secondary mt-3">Kembali ke Dashboard</a>
</div>
<footer>
    <p>&copy; 2025 Snapict. All Rights Reserved.</p>
</footer>
</body>
</html>
