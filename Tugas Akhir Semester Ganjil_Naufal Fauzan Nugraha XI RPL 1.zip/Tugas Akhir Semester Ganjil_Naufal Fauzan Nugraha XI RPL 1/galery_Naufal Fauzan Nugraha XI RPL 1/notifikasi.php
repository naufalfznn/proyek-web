<?php
session_start();
include 'koneksi.php';

// Pastikan pengguna login
if (!isset($_SESSION['UserID'])) {
    die(json_encode(["status" => "error", "message" => "Anda belum login."]));
}

$userID = $_SESSION['UserID'];

// Ambil notifikasi untuk pengguna yang belum dilihat
$query = "SELECT NotifikasiID, IsiNotifikasi, TanggalDibuat, SudahDilihat 
          FROM notifikasi 
          WHERE UserID = '$userID' 
          ORDER BY TanggalDibuat DESC";

$result = mysqli_query($con, $query);

if (!$result) {
    die(json_encode(["status" => "error", "message" => mysqli_error($con)]));
}

$notifications = [];
while ($row = mysqli_fetch_assoc($result)) {
    $notifications[] = $row;
}

// Tandai semua notifikasi sebagai sudah dilihat
$updateQuery = "UPDATE notifikasi SET SudahDilihat = 1 WHERE UserID = '$userID'";
mysqli_query($con, $updateQuery);

echo json_encode($notifications);
?>
