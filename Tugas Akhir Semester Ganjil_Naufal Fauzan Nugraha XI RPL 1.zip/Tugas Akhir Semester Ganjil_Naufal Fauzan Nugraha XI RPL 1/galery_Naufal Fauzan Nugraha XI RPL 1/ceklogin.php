<?php
session_start(); // Memulai sesi

include "koneksi.php"; // Memanggil file koneksi database

// Memeriksa apakah form sudah disubmit menggunakan POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Memeriksa apakah username dan password tidak kosong
    if (isset($_POST['Username']) && isset($_POST['Password'])) {
        $Username = $_POST['Username'];
        $Password = md5($_POST['Password']); 
        
        $query = "SELECT * FROM user WHERE Username = '$Username' AND Password = '$Password'";
        $result = mysqli_query($con, $query);

        // Mengecek apakah query berhasil dan apakah username dan password ditemukan
        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);

            $_SESSION['Username'] = $row['Username'];
            $_SESSION['UserID'] = $row['UserID'];
            $_SESSION['role'] = $row['RoleName']; 

            // Redirect ke dashboard setelah login berhasil
            header("Location: dashboard.php");
            exit();
        } else {
            // Jika login gagal
            header("Location: login.php?error=invalid"); 
            exit();
        }
    } else {
        // Jika username atau password tidak diisi
        header("Location: login.php?error=empty"); 
        exit();
    }
}
?>
