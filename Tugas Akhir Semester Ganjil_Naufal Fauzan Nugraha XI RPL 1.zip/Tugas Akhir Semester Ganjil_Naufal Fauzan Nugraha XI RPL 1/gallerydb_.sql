-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 13, 2025 at 08:00 AM
-- Server version: 8.0.30
-- PHP Version: 8.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gallerydb_`
--

-- --------------------------------------------------------

--
-- Table structure for table `album`
--

CREATE TABLE `album` (
  `AlbumID` int NOT NULL,
  `NamaAlbum` varchar(255) NOT NULL,
  `Deskripsi` text NOT NULL,
  `TanggalDibuat` date NOT NULL,
  `UserID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `album`
--

INSERT INTO `album` (`AlbumID`, `NamaAlbum`, `Deskripsi`, `TanggalDibuat`, `UserID`) VALUES
(1, 'Pemandangan', 'Landscape Fotografi', '2024-12-01', 1),
(2, 'Majalah', 'Berbagai Pose', '2024-12-01', 1),
(3, 'Hewan', 'Berbagai macam foto hewan', '2025-01-07', 2),
(4, 'PPP', 'contoh', '2025-01-13', 2),
(5, 'cnth', '111', '2025-01-13', 2);

-- --------------------------------------------------------

--
-- Table structure for table `foto`
--

CREATE TABLE `foto` (
  `FotoID` int NOT NULL,
  `JudulFoto` varchar(255) NOT NULL,
  `DeskripsiFoto` text NOT NULL,
  `TanggalUnggah` date NOT NULL,
  `LokasiFoto` varchar(255) NOT NULL,
  `AlbumID` int NOT NULL,
  `UserID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `foto`
--

INSERT INTO `foto` (`FotoID`, `JudulFoto`, `DeskripsiFoto`, `TanggalUnggah`, `LokasiFoto`, `AlbumID`, `UserID`) VALUES
(8, 'Ciwidey', 'Foto random', '2025-01-08', 'ciwideylainnya.jpg', 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `komentarfoto`
--

CREATE TABLE `komentarfoto` (
  `KomentarID` int NOT NULL,
  `FotoID` int NOT NULL,
  `UserID` int NOT NULL,
  `IsiKomentar` text NOT NULL,
  `TanggalKomentar` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `komentarfoto`
--

INSERT INTO `komentarfoto` (`KomentarID`, `FotoID`, `UserID`, `IsiKomentar`, `TanggalKomentar`) VALUES
(22, 8, 6, 'bgs bgt\r\n', '2025-01-13'),
(23, 8, 2, 'pppp', '2025-01-13');

-- --------------------------------------------------------

--
-- Table structure for table `likefoto`
--

CREATE TABLE `likefoto` (
  `LikeID` int NOT NULL,
  `FotoID` int NOT NULL,
  `UserID` int NOT NULL,
  `TanggalLike` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `likefoto`
--

INSERT INTO `likefoto` (`LikeID`, `FotoID`, `UserID`, `TanggalLike`) VALUES
(363, 8, 6, '2025-01-13'),
(369, 8, 2, '2025-01-13');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `MessageID` int NOT NULL,
  `UserID` int NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Subject` varchar(255) DEFAULT NULL,
  `Message` text,
  `CreatedAt` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`MessageID`, `UserID`, `Name`, `Email`, `Subject`, `Message`, `CreatedAt`) VALUES
(1, 3, 'Pal', 'p@gmail.com', 'Masalah', 'Ada masalah di beberapa fitur', '2025-01-07 11:03:05'),
(2, 2, 'yy', 'ppp@gmail.com', 'dew', 'www', '2025-01-08 07:00:02');

-- --------------------------------------------------------

--
-- Table structure for table `notifikasi`
--

CREATE TABLE `notifikasi` (
  `NotifikasiID` int NOT NULL,
  `UserID` int NOT NULL,
  `IsiNotifikasi` text NOT NULL,
  `TanggalDibuat` datetime DEFAULT CURRENT_TIMESTAMP,
  `SudahDilihat` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `notifikasi`
--

INSERT INTO `notifikasi` (`NotifikasiID`, `UserID`, `IsiNotifikasi`, `TanggalDibuat`, `SudahDilihat`) VALUES
(27, 2, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 06:59:01', 1),
(54, 6, 'opal telah menyukai foto Anda.', '2025-01-08 07:34:59', 1),
(55, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:41:00', 1),
(56, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:41:03', 1),
(57, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:41:04', 1),
(58, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:41:20', 1),
(59, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:45:23', 1),
(60, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:45:32', 1),
(61, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:46:07', 1),
(62, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:47:10', 1),
(63, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:49:44', 1),
(64, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:49:46', 1),
(65, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:54:15', 1),
(66, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:54:17', 1),
(67, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:54:19', 1),
(68, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:57:00', 1),
(69, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:57:01', 1),
(70, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:57:02', 1),
(71, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:58:04', 1),
(72, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:58:04', 1),
(73, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 07:58:05', 1),
(74, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 08:02:03', 1),
(75, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 08:02:09', 1),
(76, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 08:02:14', 1),
(77, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 08:06:44', 1),
(78, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 08:07:28', 1),
(79, 6, 'naufalfznn telah menyukai foto Anda.', '2025-01-08 08:07:32', 1),
(80, 6, 'naufalfznn telah mengomentari foto Anda.', '2025-01-08 08:33:22', 1),
(81, 6, 'naufalfznn telah mengomentari foto Anda.', '2025-01-08 09:15:43', 1),
(82, 6, 'naufalfznn telah mengomentari foto Anda.', '2025-01-08 09:21:58', 1),
(83, 6, 'naufalfznn telah mengomentari foto Anda.', '2025-01-08 11:20:06', 1),
(84, 2, 'naufalfznn telah mengomentari foto Anda.', '2025-01-10 20:15:56', 1),
(85, 2, 'naufalfznn telah mengomentari foto Anda.', '2025-01-10 20:22:28', 1),
(86, 6, 'naufalfznn telah mengomentari foto Anda.', '2025-01-13 09:52:43', 1),
(87, 6, 'opal telah mengomentari foto Anda.', '2025-01-13 10:54:50', 0),
(88, 6, 'naufalfznn telah mengomentari foto Anda.', '2025-01-13 11:20:53', 0);

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `RoleID` int NOT NULL,
  `RoleName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`RoleID`, `RoleName`) VALUES
(2, 'Admin'),
(1, 'User');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `NamaLengkap` varchar(255) NOT NULL,
  `Alamat` text NOT NULL,
  `RoleID` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `Username`, `Password`, `Email`, `NamaLengkap`, `Alamat`, `RoleID`) VALUES
(1, 'engkus', 'b1453a9c9d131d82f90de4a7b57b70a1', 'engkuskusnadifuture@gmail.com', 'Engkus Kusnadi', 'Cimahi', 1),
(2, 'naufalfznn', 'c4ca4238a0b923820dcc509a6f75849b', 'n@gmail.com', 'naufal', 'Cimahi', 2),
(6, 'opal', '202cb962ac59075b964b07152d234b70', 'op@gmail.com', 'PPPPP', 'CMD', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`AlbumID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `foto`
--
ALTER TABLE `foto`
  ADD PRIMARY KEY (`FotoID`),
  ADD KEY `AlbumID` (`AlbumID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `komentarfoto`
--
ALTER TABLE `komentarfoto`
  ADD PRIMARY KEY (`KomentarID`),
  ADD KEY `FotoID` (`FotoID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `likefoto`
--
ALTER TABLE `likefoto`
  ADD PRIMARY KEY (`LikeID`),
  ADD KEY `FotoID` (`FotoID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`MessageID`);

--
-- Indexes for table `notifikasi`
--
ALTER TABLE `notifikasi`
  ADD PRIMARY KEY (`NotifikasiID`),
  ADD KEY `notifikasi_ibfk_1` (`UserID`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`RoleID`),
  ADD UNIQUE KEY `RoleName` (`RoleName`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`),
  ADD KEY `RoleID` (`RoleID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `album`
--
ALTER TABLE `album`
  MODIFY `AlbumID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `foto`
--
ALTER TABLE `foto`
  MODIFY `FotoID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `komentarfoto`
--
ALTER TABLE `komentarfoto`
  MODIFY `KomentarID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `likefoto`
--
ALTER TABLE `likefoto`
  MODIFY `LikeID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=370;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `MessageID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `notifikasi`
--
ALTER TABLE `notifikasi`
  MODIFY `NotifikasiID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `RoleID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `album`
--
ALTER TABLE `album`
  ADD CONSTRAINT `album_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`);

--
-- Constraints for table `foto`
--
ALTER TABLE `foto`
  ADD CONSTRAINT `fk_foto_user` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`) ON DELETE CASCADE,
  ADD CONSTRAINT `foto_ibfk_1` FOREIGN KEY (`AlbumID`) REFERENCES `album` (`AlbumID`);

--
-- Constraints for table `komentarfoto`
--
ALTER TABLE `komentarfoto`
  ADD CONSTRAINT `fk_komentarfoto_foto` FOREIGN KEY (`FotoID`) REFERENCES `foto` (`FotoID`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_komentarfoto_user` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`) ON DELETE CASCADE,
  ADD CONSTRAINT `komentarfoto_ibfk_2` FOREIGN KEY (`FotoID`) REFERENCES `foto` (`FotoID`);

--
-- Constraints for table `likefoto`
--
ALTER TABLE `likefoto`
  ADD CONSTRAINT `fk_likefoto_foto` FOREIGN KEY (`FotoID`) REFERENCES `foto` (`FotoID`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_likefoto_user` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`) ON DELETE CASCADE,
  ADD CONSTRAINT `likefoto_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`);

--
-- Constraints for table `notifikasi`
--
ALTER TABLE `notifikasi`
  ADD CONSTRAINT `notifikasi_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`) ON DELETE CASCADE;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`RoleID`) REFERENCES `role` (`RoleID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
